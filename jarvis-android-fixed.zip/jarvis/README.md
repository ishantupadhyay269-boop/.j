# JARVIS: Android AI voice assistant
App by Ishant Upadhyay

React Native + Expo (development build), TypeScript, plus a local Kotlin Expo module.

## Honest status (v1.1: Siri-style overlay + owner voice)
- **New and NOT compiled/run anywhere:** all of `Vault.kt, Config.kt, AudioRing.kt, VoicePrint.kt, SiriOverlay.kt, AiClient.kt, Device.kt,
  CommandRouter.kt`, the rewritten `WakeWordService.kt`, and the new JS (`OwnerVoiceSetup.tsx`, settings changes). They were written without
  a Kotlin compiler or Android SDK. Expect a few compile errors on the first build; paste them back and they are quick to fix.
- Only the owner-voice algorithm was prototyped (in Python, on synthetic voices): it separates speakers **weakly**, see "Owner voice" below.
- **Verified here:** TypeScript passes a syntax/type check on the project's own code, the command router was run against ~20 sample
  utterances (English + Hindi), and the icon assets were generated.
- **NOT verified:** the Kotlin native module and the Gradle build were **never compiled**, and nothing has run on a phone yet
  (no Android SDK or network in the environment this was written in). Expect to fix a few build/runtime errors on the first build.
  Do not trust any feature until you tick it off in the test checklist below.

## Setup
1. Install Node 20+ and an EAS account: `npm i -g eas-cli`. (JDK 17 + Android Studio only if you build locally.)
2. `npm install`, then `npx expo install --fix` (aligns every package to Expo SDK 54).
3. `npx tsc --noEmit` to typecheck.
4. AI key, pick ONE:
   - **Recommended:** leave it blank and type it in Settings on the phone (stored with expo-secure-store).
   - Or `.env` (copy `.env.example`). `EXPO_PUBLIC_*` values are compiled into the APK and can be extracted. Note `.env` is git-ignored, so
     EAS cloud builds will NOT see it; set the variables in the `env` block of the profile in `eas.json` or with `eas env:create`.
   - Free option: Groq (OpenAI-compatible, default) or a Gemini key. Check each provider's current free-tier terms.

## Build the APK
```
eas login
eas build:configure
npm run build:apk          # = eas build -p android --profile preview  -> gives a download link to a .apk
```
Local alternative: `npm run apk:local` (needs Android Studio SDK + JDK 17; release signing needs a keystore, EAS manages one for you).
Install: open the link on the phone, or `adb install jarvis.apk`, and allow "install unknown apps".
This app uses native code, so it will **not** run in Expo Go.

## "Hello Jarvis" in the background: first-run steps
1. Settings → **Listen in background** → allow microphone + notifications. A persistent notification appears (with a Stop button).
2. Tap **1. Allow draw over other apps** (Android 10+ needs this so a background service can open the app).
3. Tap **2. Disable battery optimization**, then **3. Autostart settings**. On Xiaomi/Oppo/Vivo/Samsung/OnePlus/Huawei also lock JARVIS in Recents.
4. Close the app, lock the phone, say "Hello Jarvis" (or "Hey Jarvis"). Expected: spoken "Yes Sir.", screen turns on, JARVIS opens and listens.
   Over a lock screen it only shows itself; anything protected still needs you to unlock. JARVIS cannot bypass the lock screen.

### How it works
`WakeWordService.kt` is a foreground service (type microphone) looping Android's `SpeechRecognizer` and matching "jarvis"
(English and Hindi spellings, or your custom word). On a match it says "Yes Sir.", wakes the screen, starts the activity
(`showWhenLocked`/`turnScreenOn` via `plugins/withJarvisActivity.js`), and the JS side starts listening for your command.
A heads-up notification is the fallback if the overlay permission is missing.

### Siri-style overlay (app stays closed)
Say "Hello Jarvis" (or "Hello Jarvis, open camera" in one go). A glowing wave rises at the bottom of the screen, JARVIS says "Yes Sir.",
listens, runs the command natively and speaks the answer. Tap the overlay to dismiss. The JARVIS app is not opened.
- Commands run in Kotlin (`CommandRouter.kt`, same rules as `CommandProcessor.ts`): open apps, YouTube, camera, settings pages, dial/SMS composer,
  web search, flashlight, volume, battery, network, time/date, lock. Alarms and timers are now set directly (no Clock confirmation).
- Anything else goes to your AI provider (`AiClient.kt`). The AI key and settings are copied from the app into an encrypted store
  (Android Keystore, AES-GCM) each time you change a setting, so **open the app once after updating** so the copy exists.
- "Authenticate me ..." needs the biometric prompt, so that one command opens the app and continues there.
- What happened while the app was closed is added to the in-app history next time you open it.
- Needs "Draw over other apps" (Settings step 1). Without it, or with the switch off, or when the app is already on screen, JARVIS uses the old behaviour (opens the app).
- **While the phone is locked:** the overlay window cannot be drawn over the lock screen, so JARVIS still answers by voice but you will see nothing, and commands
  that launch other apps reply "Please unlock your phone first, Sir." (Time, battery, volume, flashlight, timers, alarms and AI answers still work.)
  A lock-screen-capable version would need a transparent show-when-locked Activity; not built.

### Owner voice (Settings -> Siri-style wake & owner voice)
You say "Hello Jarvis" 5 times; `VoicePrint.kt` stores an encrypted numeric voiceprint (12 MFCC means + 12 MFCC std-devs + median pitch). No audio is saved.
With "Only respond to my voice" on, the service keeps the last 4 s of microphone audio **in memory only** and compares it when the wake word is heard.
**Do not treat this as security.** In my synthetic-voice test the best setting rejected about 6% of the owner's attempts while still accepting about 1 in 4 impostors;
real phones, noise and distance will be worse. It is a filter against TV/other people, nothing more. Sensitive actions keep their own checks (biometrics, device admin).
Known risks, all unverified on a real phone:
- Reading the mic in the service at the same time as Google's recognizer may give the app silent audio on some phones. Then the check cannot run, the wake is **allowed**
  (fails open) and Settings shows why. If the recognizer errors because of the shared mic, the audio buffer switches itself off for 10 minutes.
- Continuous in-memory recording while the lock is on costs extra battery.
- For real accuracy replace `VoicePrint.embed()` with an on-device neural speaker-embedding model (e.g. a TFLite d-vector/ECAPA model); the enroll/verify plumbing stays the same.

### Limits (be aware)
- Not a dedicated hotword DSP: noticeable battery use, possible recognizer beeps on some phones, accuracy depends on Google's speech service.
  For better accuracy/battery, swap in Picovoice Porcupine (limited free tier) behind `WakeWordEngine.ts`.
- Only one app can hold the microphone: JARVIS pauses the service while the app itself is listening.
- Android 14+ blocks starting a microphone service from boot. After a restart JARVIS posts a notification; tap it once.
- Some manufacturers kill background services regardless of settings. Screen-off wake therefore varies per phone.
- Not implemented: `VoiceInteractionService` (default-assistant slot / power-button long-press), lock-screen overlay, contact-name calling.

## What commands can and can't do
Works through official Android APIs: open apps, YouTube (search/play), camera, settings pages, dialer (you press call), SMS composer
(you press send), web search, flashlight, volume, alarms/reminders/timers (opens the Clock app prefilled; you confirm), battery, network,
time/date, lock screen (needs Device Admin), biometric authentication.
Cannot: unlock the lock screen, read your PIN, call/send SMS silently, search contacts (no contacts permission requested).
"Unlock my phone" only runs the system biometric/device-credential prompt, then tells you to unlock Android yourself.
Anything else is sent to the AI model (English, Hindi, Hinglish; follow-ups use the last 12 messages).

## Permissions
RECORD_AUDIO (speech), POST_NOTIFICATIONS + FOREGROUND_SERVICE(_MICROPHONE) (background listening notification),
SYSTEM_ALERT_WINDOW (open the app from the background), USE_FULL_SCREEN_INTENT (tap-to-open fallback), REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
USE_BIOMETRIC, MODIFY_AUDIO_SETTINGS (volume), SET_ALARM (Clock app intents), WAKE_LOCK (turn screen on), RECEIVE_BOOT_COMPLETED (post the
"resume listening" notification). Device Admin (force-lock only) is requested only when you use Phone Lock.

## Test checklist
- [ ] App builds, launches, orb animates.
- [ ] Mic button: English recognised, then Hindi (Settings → Language).
- [ ] Typed question gets an AI answer and is spoken.
- [ ] "open camera", "open youtube", "flashlight on", "battery", "set alarm for 7 am", "set timer for 2 minutes".
- [ ] "authenticate me and open youtube" → biometric prompt → YouTube opens.
- [ ] "lock my phone" → device-admin prompt → screen locks.
- [ ] Background wake: app in Recents, then app swiped away, then screen locked/off.
- [ ] Stop listening from the notification → Settings switch turns off when you reopen the app.

## Known risks on first build
- `@react-native-voice/voice` 3.x is old; `newArchEnabled` is set to `false` in app.json for it. If it fails to compile, the fallback is a
  small native `SpeechRecognizer` wrapper in the Kotlin module (the service already contains the pattern).
- Package versions are `*` until you run `npx expo install --fix`.
- Conversation history is in app-private storage (not separately encrypted) and excluded from Android backups.

## Test checklist (v1.1 additions)
- [ ] Settings: grant "Draw over other apps"; open the app once; turn on Listen in background; close the app.
- [ ] Home screen: "Hello Jarvis" -> wave appears, "Yes Sir.", say "what's the battery" -> spoken answer, overlay slides away.
- [ ] "Hello Jarvis open camera" in one sentence; "Hello Jarvis set timer for 2 minutes"; "Hello Jarvis tell me a joke" (AI).
- [ ] Reopen the app: the exchanges appear in history. "Hello Jarvis authenticate me" opens the app and shows the biometric prompt.
- [ ] Owner voice: record 5 samples, "Test my voice" shows a match; a friend saying it should usually show "Not a match".
- [ ] Turn on "Only respond to my voice"; check the status line under it after a few wakes (matched / ignored / unavailable).
- [ ] Locked phone: "Hello Jarvis what time is it" answers by voice; "open youtube" asks you to unlock.

## Layout
`src/modules/`: VoiceEngine, WakeWordEngine, AIEngine, SpeechEngine, AndroidDeviceController, AuthenticationManager, CommandProcessor,
ConversationManager, SettingsManager. `src/ui/`: MainUI, Orb, SettingsScreen, useJarvis.
`modules/jarvis-native/`: Kotlin Expo module (wake service + Siri-style overlay `SiriOverlay.kt`, `CommandRouter.kt`, `AiClient.kt`, owner voice `VoicePrint.kt`/`AudioRing.kt`, encrypted `Vault.kt`, boot receiver, device admin, device helpers).
`plugins/withJarvisActivity.js`: lets the activity show over the lock screen.
