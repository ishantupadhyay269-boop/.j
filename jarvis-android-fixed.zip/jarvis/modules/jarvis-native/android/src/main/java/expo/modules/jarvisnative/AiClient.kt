package expo.modules.jarvisnative

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Same providers as the JS AIEngine (OpenAI-compatible, Gemini), so answers also work with the app closed. */
object AiClient {
  private const val SYSTEM = "You are JARVIS, a polite, intelligent, confident voice assistant. Address the user as \"Sir\". " +
    "Reply in the language the user used (English, Hindi, or Hinglish mixed). Keep answers short and speakable: " +
    "1-3 sentences unless asked to explain in detail. No markdown, no emojis, no lists read aloud. " +
    "You can calculate, translate, summarize and explain. Never claim you performed a phone action; device actions are handled separately."

  /** history: list of (role, text) with role "user" | "assistant". Never throws; returns a speakable message. */
  fun ask(cfg: Config, history: List<Pair<String, String>>): String {
    if (cfg.aiApiKey.isBlank()) return "My AI service is not configured yet, Sir. Please add an API key in Settings."
    val system = SYSTEM + "\nCurrent date and time: " + java.util.Date().toString() + "."
    return try {
      if (cfg.aiProvider == "gemini") gemini(cfg, history, system) else openai(cfg, history, system)
    } catch (e: HttpError) {
      when (e.code) {
        401, 403 -> "My AI service rejected the API key, Sir. Please check it in Settings."
        429 -> "My AI service is rate limited at the moment, Sir. Please try again shortly."
        else -> "I'm unable to reach my AI service, Sir."
      }
    } catch (_: java.net.SocketTimeoutException) {
      "My AI service took too long to answer, Sir."
    } catch (_: Exception) {
      "I'm unable to reach my AI service, Sir. Basic commands still work offline."
    }
  }

  private class HttpError(val code: Int) : Exception()

  private fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
    val c = URL(url).openConnection() as HttpURLConnection
    try {
      c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 25000; c.doOutput = true
      c.setRequestProperty("Content-Type", "application/json")
      headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
      c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
      if (c.responseCode !in 200..299) throw HttpError(c.responseCode)
      return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
    } finally { c.disconnect() }
  }

  private fun openai(cfg: Config, h: List<Pair<String, String>>, system: String): String {
    val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
    h.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
    val j = post(cfg.aiBaseUrl.trimEnd('/') + "/chat/completions", mapOf("Authorization" to "Bearer ${cfg.aiApiKey}"),
      JSONObject().put("model", cfg.aiModel).put("temperature", 0.6).put("messages", msgs))
    return j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content", "")?.trim().orEmpty()
  }

  private fun gemini(cfg: Config, h: List<Pair<String, String>>, system: String): String {
    val contents = JSONArray()
    h.forEach {
      contents.put(JSONObject().put("role", if (it.first == "assistant") "model" else "user")
        .put("parts", JSONArray().put(JSONObject().put("text", it.second))))
    }
    val j = post("https://generativelanguage.googleapis.com/v1beta/models/${cfg.aiModel}:generateContent",
      mapOf("x-goog-api-key" to cfg.aiApiKey),
      JSONObject().put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        .put("contents", contents))
    val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
    return (0 until parts.length()).joinToString("") { parts.optJSONObject(it)?.optString("text", "") ?: "" }.trim()
  }
}
