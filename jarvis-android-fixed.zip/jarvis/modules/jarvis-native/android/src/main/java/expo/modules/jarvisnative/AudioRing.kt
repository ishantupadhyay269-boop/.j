package expo.modules.jarvisnative

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.max
import kotlin.math.min

/**
 * Keeps the last few seconds of microphone audio IN MEMORY ONLY (never written to disk) so the
 * wake service can check whose voice said "Hello Jarvis". Only runs while the owner-voice check is on.
 */
class AudioRing(seconds: Int = 4) {
  private val buf = ShortArray(VoicePrint.SR * seconds)
  private var pos = 0
  private var filled = 0
  private var rec: AudioRecord? = null
  @Volatile private var running = false

  fun start(): Boolean {
    return try {
      val minBuf = AudioRecord.getMinBufferSize(VoicePrint.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
      val r = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, VoicePrint.SR, AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 8192))
      if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return false }
      r.startRecording()
      rec = r
      running = true
      Thread({
        val tmp = ShortArray(1600)
        while (running) {
          val n = try { r.read(tmp, 0, tmp.size) } catch (_: Exception) { -1 }
          if (n <= 0) { if (!running) break; try { Thread.sleep(20) } catch (_: InterruptedException) {}; continue }
          synchronized(buf) {
            for (i in 0 until n) { buf[pos] = tmp[i]; pos = (pos + 1) % buf.size }
            filled = min(buf.size, filled + n)
          }
        }
      }, "jarvis-ring").start()
      true
    } catch (_: Exception) { stop(); false }
  }

  /** Last [seconds] of audio, oldest first. */
  fun snapshot(seconds: Double): ShortArray {
    synchronized(buf) {
      val n = min(filled, (seconds * VoicePrint.SR).toInt())
      val out = ShortArray(n)
      var p = (pos - n + buf.size) % buf.size
      for (i in 0 until n) { out[i] = buf[p]; p = (p + 1) % buf.size }
      return out
    }
  }

  fun stop() {
    running = false
    try { rec?.stop() } catch (_: Exception) {}
    try { rec?.release() } catch (_: Exception) {}
    rec = null
  }

  companion object {
    /** Blocking capture used by enrollment / testing in the app (the wake service is paused meanwhile). */
    fun captureBlocking(seconds: Double): ShortArray? {
      return try {
        val total = (seconds * VoicePrint.SR).toInt()
        val minBuf = AudioRecord.getMinBufferSize(VoicePrint.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, VoicePrint.SR, AudioFormat.CHANNEL_IN_MONO,
          AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 8192))
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return null }
        val out = ShortArray(total)
        r.startRecording()
        var got = 0
        while (got < total) {
          val n = r.read(out, got, min(1600, total - got))
          if (n <= 0) break
          got += n
        }
        r.stop(); r.release()
        if (got < total / 2) null else out.copyOf(got)
      } catch (_: Exception) { null }
    }
  }
}
