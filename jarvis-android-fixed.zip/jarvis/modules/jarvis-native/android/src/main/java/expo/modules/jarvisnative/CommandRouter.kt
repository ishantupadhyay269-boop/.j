package expo.modules.jarvisnative

import android.app.admin.DevicePolicyManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import java.text.DateFormat
import java.util.Date
import java.util.Locale

/**
 * Kotlin port of src/modules/CommandProcessor.ts so commands run while the React app is closed.
 * Returns null when the text is not a device command (the caller then asks the AI).
 */
object CommandRouter {
  sealed class Result {
    class Reply(val text: String) : Result()
    /** Needs the full app (e.g. biometric prompt). [command] is replayed inside the app. */
    class NeedsApp(val text: String, val command: String) : Result()
  }

  private const val T = "Sir"
  private const val OPEN = "(?:open|launch|start|kholo|khol do|खोलो|खोलिए|खोल दो|चालू करो|chalu karo)"
  private const val YT = "(?:youtube|यूट्यूब|यूटयूब)"
  private const val CAM = "(?:camera|कैमरा|कैमेरा)"

  private val SETTINGS = mapOf(
    "wifi" to Settings.ACTION_WIFI_SETTINGS, "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
    "display" to Settings.ACTION_DISPLAY_SETTINGS, "sound" to Settings.ACTION_SOUND_SETTINGS,
    "battery" to Intent.ACTION_POWER_USAGE_SUMMARY, "location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
    "apps" to Settings.ACTION_APPLICATION_SETTINGS, "accessibility" to Settings.ACTION_ACCESSIBILITY_SETTINGS,
    "security" to Settings.ACTION_SECURITY_SETTINGS, "main" to Settings.ACTION_SETTINGS,
  )

  private fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE)
  private fun num(s: String) = (Regex("""\+?\d[\d\s-]{4,}""").find(s)?.value ?: "").replace(Regex("""[\s-]"""), "")

  private fun go(ctx: Context, i: Intent): Boolean = try {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
  } catch (_: ActivityNotFoundException) { false } catch (_: SecurityException) { false }

  private fun url(ctx: Context, u: String) = go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))

  fun handle(ctx: Context, raw: String, locked: Boolean): Result? {
    val t = raw.lowercase(Locale.ROOT).trim()
      .replace(rx("""^(?:hello|hallo|hey|hi|ok|okay|हेलो|हैलो|हे)\s+(?:jarvis|जार्विस|जारविस)[\s,.:!-]*"""), "")
      .replace(rx("""^(?:jarvis|जार्विस|जारविस)[\s,.:!-]*"""), "")
      .replace(rx("""[\s.,!?।]+$"""), "")
      .trim()
    if (t.isEmpty()) return null
    var m: MatchResult?
    fun r(s: String) = Result.Reply(s)
    val unlockMsg = Result.Reply("Please unlock your phone first, $T.")

    // authentication needs the BiometricPrompt UI, so hand over to the app
    if (rx("""^(?:authenticate me(?: and (.+))?|unlock (?:my )?phone|open my phone)$""").matches(t))
      return Result.NeedsApp("Certainly, $T. Opening JARVIS so you can authenticate.", t)

    // lock phone
    if (rx("""^(lock (?:my |the )?(?:phone|screen)|phone lock karo|फोन लॉक करो)$""").matches(t)) {
      val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
      val admin = ComponentName(ctx, JarvisAdminReceiver::class.java)
      if (!dpm.isAdminActive(admin)) return r("I need device administrator permission to lock the screen, $T. Please enable it in JARVIS settings.")
      dpm.lockNow(); return r("")
    }

    // time / date
    if (rx("""^(?:what(?:'s| is) the time(?: now)?|what time is it(?: now)?|current time|time|time kya hai|abhi kitne baje hain?|समय क्या है|टाइम क्या है)$""").matches(t))
      return r("It is ${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())}, $T.")
    if (rx("""^(?:what(?:'s| is)(?: the| today's)? date(?: today)?|today's date|current date|date|aaj ki tarikh(?: kya hai)?|आज की तारीख(?: क्या है)?)$""").matches(t))
      return r("Today is ${DateFormat.getDateInstance(DateFormat.FULL).format(Date())}, $T.")

    // battery / network
    if (rx("""^(?:what(?:'s| is) (?:my |the )?)?battery(?: level| status| percentage| percent)?(?: left)?$|^how much battery(?: do i have| is left)?$|battery kitni|बैटरी कितनी""").containsMatchIn(t)) {
      val (p, ch) = Device.battery(ctx)
      return r("Battery is at $p percent${if (ch) " and charging" else ""}, $T.")
    }
    if (rx("""^(?:network|internet|wifi|connection)(?: status)?$|^(?:am i|are we) (?:online|connected)|^(?:check|is my) (?:the |my )?(?:network|internet|wifi)""").containsMatchIn(t)) {
      val (on, type) = Device.network(ctx)
      return r(if (on) "You are online via $type, $T." else "You appear to be offline, $T.")
    }

    // flashlight
    m = rx("""\b(?:(?:turn |switch )?(on|off)(?: the)? (?:flashlight|torch)|(?:flashlight|torch) (on|off)|torch (jalao|band karo))""").find(t)
    if (m != null) {
      val g = m.groupValues
      val on = (g[1].ifEmpty { g[2].ifEmpty { if (g[3] == "jalao") "on" else "off" } }) == "on"
      return r(if (Device.setFlashlight(ctx, on)) "Flashlight ${if (on) "on" else "off"}, $T." else "I could not control the flashlight on this device, $T.")
    }

    // volume
    m = rx("""\bvolume (?:to |set to )?(\d{1,3})(?:\s*(?:percent|%))?""").find(t)
    if (m != null) { val v = m.groupValues[1].toInt().coerceIn(0, 100); Device.setVolume(ctx, v); return r("Volume set to $v percent, $T.") }
    if (rx("""(?:\bvolume (?:up|increase)\b|\blouder\b|awaaz badhao|आवाज़ बढ़ाओ)""").containsMatchIn(t)) { Device.setVolume(ctx, Device.getVolume(ctx) + 15); return r("Volume increased, $T.") }
    if (rx("""(?:\bvolume (?:down|decrease)\b|\bquieter\b|awaaz kam karo|आवाज़ कम करो)""").containsMatchIn(t)) { Device.setVolume(ctx, Device.getVolume(ctx) - 15); return r("Volume decreased, $T.") }

    // timer (set directly, no Clock UI)
    m = rx("""\b(?:set (?:a )?timer (?:for )?|timer (?:for )?)(\d+)\s*(second|sec|minute|min|hour|hr)s?\b""").find(t)
    if (m != null) {
      val n = m.groupValues[1].toInt(); val u = m.groupValues[2]
      val secs = if (u.startsWith("h")) n * 3600 else if (u.startsWith("m")) n * 60 else n
      val ok = go(ctx, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs)
        .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
      val unit = when { u.startsWith("h") -> "hour"; u.startsWith("m") -> "minute"; else -> "second" }
      return r(if (ok) "Timer set for $n $unit${if (n != 1) "s" else ""}, $T." else "I could not set a timer on this phone, $T.")
    }

    // reminder (labelled alarm) and alarm
    m = rx("""^remind me (?:to )?(.+?) (?:at|by) (\d{1,2})(?::(\d{2}))?\s*(am|pm)?$""").find(t)
    if (m != null) {
      val (h, min) = clock(m.groupValues[2], m.groupValues[3], m.groupValues[4])
      return r(if (alarm(ctx, h, min, m.groupValues[1])) "Reminder set for ${hhmm(h, min)}, $T." else "I could not set that reminder, $T.")
    }
    m = rx("""\b(?:set (?:an )?alarm (?:for|at)|alarm (?:set karo|lagao))\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""").find(t)
    if (m != null) {
      val (h, min) = clock(m.groupValues[1], m.groupValues[2], m.groupValues[3])
      return r(if (alarm(ctx, h, min, "JARVIS")) "Alarm set for ${hhmm(h, min)}, $T." else "I could not set that alarm, $T.")
    }

    // everything below launches another app: not while the phone is locked
    val opensApp = rx("""^(?:$OPEN\s+.+|.+\s+$OPEN|(?:play|search)\s+.+\s+on youtube|youtube (?:par|pe)\s+.+|(?:call|dial|phone)\s+.+|(?:send (?:an )?(?:sms|text|message)|text)\s+.+|(?:search(?: the web| google)? for|google|search)\s+.+|(?:settings|सेटिंग्स)\s+$OPEN)$""").matches(t)
    if (opensApp && locked) return unlockMsg

    // YouTube
    m = rx("""\b(?:play|search)\s+(.+?)\s+on youtube\b""").find(t) ?: rx("""\byoutube (?:par|pe)\s+(.+?)\s+(?:chalao|search karo)\b""").find(t)
    if (m != null) { url(ctx, "https://www.youtube.com/results?search_query=" + Uri.encode(m.groupValues[1])); return r("Searching YouTube for ${m.groupValues[1]}, $T.") }
    if (rx("^$OPEN\\s+$YT$|^$YT\\s+$OPEN$").matches(t)) {
      if (Device.launchAppByName(ctx, "YouTube") == null) url(ctx, "https://m.youtube.com")
      return r("Opening YouTube, $T.")
    }

    // camera / settings
    if (rx("^$OPEN\\s+(?:the\\s+)?$CAM$|^$CAM\\s+$OPEN$").matches(t)) {
      return r(if (go(ctx, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) "Opening the camera, $T." else "I could not open the camera, $T.")
    }
    m = rx("^$OPEN\\s+(?:the\\s+)?(?:(${SETTINGS.keys.joinToString("|")})\\s+)?settings$|^(?:settings|सेटिंग्स)\\s+$OPEN$").find(t)
    if (m != null) { go(ctx, Intent(SETTINGS[m.groupValues[1].ifEmpty { "main" }] ?: Settings.ACTION_SETTINGS)); return r("Opening settings, $T.") }

    // phone / SMS
    m = rx("""^(?:call|dial|phone)\s+(.+)$""").find(t)
    if (m != null) {
      val n = num(m.groupValues[1])
      if (n.isEmpty()) return r("I can only dial numbers for now, $T. Please say the number.")
      go(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))); return r("Opening the dialer with $n, $T. Press call to connect.")
    }
    m = rx("""^(?:send (?:an )?(?:sms|text|message)|text)\s+(?:to\s+)?(\+?[\d\s-]{5,})\s*(?:saying|that says|message|:)?\s*(.*)$""").find(t)
    if (m != null) {
      go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("sms:${num(m.groupValues[1])}")).putExtra("sms_body", m.groupValues[2]))
      return r("Composing your message, $T. Please press send.")
    }

    // web search
    m = rx("""^(?:search(?: the web| google)? for|google|search)\s+(.+)$""").find(t)
    if (m != null) { url(ctx, "https://www.google.com/search?q=" + Uri.encode(m.groupValues[1])); return r("Searching for ${m.groupValues[1]}, $T.") }

    // generic open app
    m = rx("^$OPEN\\s+(.+)$").find(t) ?: rx("^(.+?)\\s+$OPEN$").find(t)
    if (m != null) {
      val name = m.groupValues[1].replace(rx("""^the\s+|\s+app$"""), "")
      val label = try { Device.launchAppByName(ctx, name) } catch (_: Exception) { null }
      return r(if (label != null) "Opening $label, $T." else "I could not find an app called $name, $T.")
    }
    return null
  }

  private fun clock(h0: String, m0: String, ap: String): Pair<Int, Int> {
    var h = h0.toInt(); val min = if (m0.isEmpty()) 0 else m0.toInt()
    if (ap == "pm" && h < 12) h += 12
    if (ap == "am" && h == 12) h = 0
    return Pair(h, min)
  }

  private fun hhmm(h: Int, m: Int) = "$h:${m.toString().padStart(2, '0')}"

  private fun alarm(ctx: Context, h: Int, m: Int, label: String) =
    go(ctx, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
      .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
}
