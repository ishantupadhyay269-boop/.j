package expo.modules.jarvisnative

import android.content.Context
import org.json.JSONObject

/** Copy of the JS Settings that the background assistant needs. JS pushes it via syncConfig(). */
data class Config(
  val language: String = "auto",
  val speechRate: Float = 1f,
  val voice: String? = null,
  val continuous: Boolean = true,
  val wakeMode: String = "overlay",      // "overlay" = Siri-style, app stays closed; "app" = open full app
  val voiceLock: Boolean = false,
  val strictness: String = "normal",     // strict | normal | relaxed
  val aiProvider: String = "openai",
  val aiBaseUrl: String = "https://api.groq.com/openai/v1",
  val aiModel: String = "llama-3.3-70b-versatile",
  val aiApiKey: String = "",
) {
  companion object {
    @Volatile private var cached: Config? = null

    private fun parse(json: String): Config {
      val o = JSONObject(json)
      val d = Config()
      return Config(
        language = o.optString("language", d.language),
        speechRate = o.optDouble("speechRate", d.speechRate.toDouble()).toFloat(),
        voice = o.optString("voice", "").ifEmpty { null },
        continuous = o.optBoolean("continuous", d.continuous),
        wakeMode = o.optString("wakeMode", d.wakeMode),
        voiceLock = o.optBoolean("voiceLock", d.voiceLock),
        strictness = o.optString("voiceStrictness", d.strictness),
        aiProvider = o.optString("aiProvider", d.aiProvider),
        aiBaseUrl = o.optString("aiBaseUrl", d.aiBaseUrl),
        aiModel = o.optString("aiModel", d.aiModel),
        aiApiKey = o.optString("aiApiKey", d.aiApiKey),
      )
    }

    fun load(ctx: Context): Config {
      cached?.let { return it }
      val c = try { Vault.get(ctx, "config")?.let { parse(it) } } catch (_: Exception) { null } ?: Config()
      cached = c
      return c
    }

    fun save(ctx: Context, json: String) {
      Vault.put(ctx, "config", json)
      cached = try { parse(json) } catch (_: Exception) { Config() }
    }
  }
}
