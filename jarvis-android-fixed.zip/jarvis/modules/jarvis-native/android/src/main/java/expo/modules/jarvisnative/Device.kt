package expo.modules.jarvisnative

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager

/** Device actions shared by the JS module and the background command router. */
object Device {
  fun launchAppByName(ctx: Context, name: String): String? {
    val pm = ctx.packageManager
    val q = name.trim().lowercase()
    val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val matches = pm.queryIntentActivities(main, 0)
    val hit = matches.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
      ?: matches.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
      ?: return null
    val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return null
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    ctx.startActivity(i)
    return hit.loadLabel(pm).toString()
  }

  fun setFlashlight(ctx: Context, on: Boolean): Boolean {
    return try {
      val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
      val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        ?: return false
      cm.setTorchMode(id, on); true
    } catch (_: Exception) { false }
  }

  fun getVolume(ctx: Context): Int {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    return (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
  }

  fun setVolume(ctx: Context, percent: Int) {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent.coerceIn(0, 100) * max) / 100, AudioManager.FLAG_SHOW_UI)
  }

  /** (percent, charging) */
  fun battery(ctx: Context): Pair<Int, Boolean> {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
    return Pair(if (level < 0) 0 else level * 100 / scale, charging)
  }

  /** (online, "wifi"/"cellular"/...) */
  fun network(ctx: Context): Pair<Boolean, String> {
    val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork)
    val online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
    val type = when {
      caps == null -> "none"
      caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
      caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
      caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
      else -> "other"
    }
    return Pair(online, type)
  }
}
