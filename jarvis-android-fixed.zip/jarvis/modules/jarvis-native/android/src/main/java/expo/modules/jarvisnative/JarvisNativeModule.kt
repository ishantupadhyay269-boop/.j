package expo.modules.jarvisnative

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class JarvisNativeModule : Module() {
  private val ctx: Context get() = appContext.reactContext ?: throw IllegalStateException("React context lost")
  private val prefs get() = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
  private val admin get() = ComponentName(ctx, JarvisAdminReceiver::class.java)
  private val enroll = mutableListOf<DoubleArray>()

  private fun launchSettings(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

  /** Known vendor "autostart / background" screens. Names change between ROM versions, so each is best-effort. */
  private val oemAutostart = listOf(
    "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
    "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
    "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
    "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
    "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
    "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
    "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity",
    "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity",
  )

  override fun definition() = ModuleDefinition {
    Name("JarvisNative")
    Events("onWake")

    OnCreate { WakeBus.listener = { p -> sendEvent("onWake", mapOf("phrase" to p)) } }
    OnDestroy { WakeBus.listener = null }

    // ---- wake word service ----
    Function("startWakeService") {
      if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
        false
      } else {
        prefs.edit().putBoolean("wake_enabled", true).apply()
        ctx.startForegroundService(Intent(ctx, WakeWordService::class.java))
        true
      }
    }
    Function("stopWakeService") {
      prefs.edit().putBoolean("wake_enabled", false).apply()
      ctx.stopService(Intent(ctx, WakeWordService::class.java))
      WakeBus.running = false
      true
    }
    Function("isWakeServiceRunning") { WakeBus.running }
    /** What the user last asked for (also cleared if they tap "Stop listening" in the notification). */
    Function("isWakeEnabled") { prefs.getBoolean("wake_enabled", false) }
    /** Comma-separated custom wake words; empty string = built-in "jarvis" variants. */
    Function("setWakeWords") { csv: String -> prefs.edit().putString("wake_words", csv.lowercase()).apply(); true }
    Function("pauseWake") { WakeBus.paused.set(true); WakeBus.onPause?.invoke(); true }
    Function("resumeWake") { WakeBus.paused.set(false); true }
    /** True only if the service heard the wake word in the last 60 s (stale triggers are ignored). */
    Function("consumePendingWake") {
      val ts = prefs.getLong("pending_wake_ts", 0L)
      if (ts != 0L) prefs.edit().putLong("pending_wake_ts", 0L).apply()
      ts != 0L && System.currentTimeMillis() - ts < 60_000L
    }

    // ---- permissions / settings helpers ----
    Function("canDrawOverlays") { Settings.canDrawOverlays(ctx) }
    Function("requestOverlayPermission") {
      launchSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))); true
    }
    Function("isIgnoringBatteryOptimizations") {
      (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    Function("requestIgnoreBatteryOptimizations") {
      launchSettings(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))); true
    }
    Function("manufacturer") { Build.MANUFACTURER ?: "" }
    /** Opens the vendor autostart screen if one exists; otherwise this app's system info page. Returns true if a vendor screen opened. */
    Function("openAutostartSettings") {
      var opened = false
      for ((pkg, cls) in oemAutostart) {
        try {
          launchSettings(Intent().setComponent(ComponentName(pkg, cls)))
          opened = true
          break
        } catch (_: Exception) {}
      }
      if (!opened) launchSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
      opened
    }

    // ---- device admin / lock ----
    Function("isAdminActive") {
      (ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(admin)
    }
    Function("requestAdmin") {
      launchSettings(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Lets JARVIS lock your screen when you ask. It cannot unlock or read your PIN.")
      }); true
    }
    Function("lockNow") {
      val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
      if (!dpm.isAdminActive(admin)) false else { dpm.lockNow(); true }
    }

    // ---- device control ----
    Function("launchAppByName") { name: String -> Device.launchAppByName(ctx, name) }
    Function("setFlashlight") { on: Boolean -> Device.setFlashlight(ctx, on) }
    Function("getVolume") { Device.getVolume(ctx) }
    Function("setVolume") { percent: Int -> Device.setVolume(ctx, percent); true }

    // ---- background assistant (Siri-style overlay) ----
    /** JS pushes its Settings JSON here; stored encrypted so the service can use it with the app closed. */
    Function("syncConfig") { json: String -> Config.save(ctx, json); true }
    Function("setAppForeground") { fg: Boolean -> WakeBus.appForeground = fg; true }
    /** JSON array [{u, a}] of exchanges handled while the app was closed; cleared when read. */
    Function("consumeNativeLog") {
      val v = prefs.getString("native_log", "") ?: ""
      if (v.isNotEmpty()) prefs.edit().remove("native_log").apply()
      v
    }
    /** A command the overlay could not run itself (e.g. needs biometrics); the app replays it. */
    Function("consumePendingCommand") {
      val v = prefs.getString("pending_command", "") ?: ""
      if (v.isNotEmpty()) prefs.edit().remove("pending_command").apply()
      v
    }
    Function("lastWakeCheck") { prefs.getString("last_wake_check", "") ?: "" }

    // ---- owner voice ----
    Function("voiceEnrolled") { VoicePrint.enrolled(ctx) }
    Function("clearVoiceprint") { VoicePrint.clear(ctx); enroll.clear(); true }
    Function("enrollReset") { enroll.clear(); true }
    /** Records ~3 s and stores one enrollment sample. JS pauses the wake service first so the mic is free. */
    AsyncFunction("enrollRecordSample") {
      val pcm = AudioRing.captureBlocking(3.0)
      if (pcm == null) mapOf("ok" to false, "reason" to "mic_unavailable", "count" to enroll.size)
      else {
        var peak = 0
        for (v in pcm) peak = maxOf(peak, Math.abs(v.toInt()))
        val e = if (peak < 400) null else VoicePrint.embed(pcm)
        if (e == null) mapOf("ok" to false, "reason" to (if (peak < 400) "too_quiet" else "no_voice"), "count" to enroll.size)
        else { enroll.add(e); mapOf("ok" to true, "reason" to "", "count" to enroll.size) }
      }
    }
    Function("enrollFinish") {
      val base = VoicePrint.enroll(ctx, enroll.toList())
      if (base != null) enroll.clear()
      mapOf("ok" to (base != null), "baseline" to (base ?: 0.0))
    }
    /** Records ~3 s and reports whether it matches the saved voiceprint. state: match | reject | silent | no_voice | no_print | mic_unavailable */
    AsyncFunction("testVoice") {
      val pcm = AudioRing.captureBlocking(3.0)
      if (pcm == null) mapOf("state" to "mic_unavailable", "distance" to 0.0, "threshold" to 0.0)
      else {
        val v = VoicePrint.verify(ctx, pcm, Config.load(ctx).strictness)
        mapOf("state" to v.state.name.lowercase(), "distance" to v.distance, "threshold" to v.threshold)
      }
    }
  }
}
