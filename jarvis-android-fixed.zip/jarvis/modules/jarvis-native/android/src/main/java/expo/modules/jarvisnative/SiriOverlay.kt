package expo.modules.jarvisnative

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

enum class OverlayState { LISTENING, THINKING, SPEAKING }

/** Animated, Siri-style waves along the bottom edge of the screen. Drawn with plain Canvas, no assets. */
class SiriWaveView(ctx: Context) : View(ctx) {
  var state = OverlayState.LISTENING
    set(v) { if (field != v) { field = v; rebuildShaders() } }
  @Volatile var level = 0f

  private var phase = 0f
  private var amp = 0.1f
  private var last = SystemClock.uptimeMillis()
  private val line = Path()
  private val fill = Path()
  private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
  private val area = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

  private fun palette(): IntArray = when (state) {
    OverlayState.LISTENING -> intArrayOf(0xFF00E0FF.toInt(), 0xFF3B82FF.toInt(), 0xFFB04CFF.toInt())
    OverlayState.THINKING -> intArrayOf(0xFFB04CFF.toInt(), 0xFFFF4DA6.toInt(), 0xFF7A5CFF.toInt())
    OverlayState.SPEAKING -> intArrayOf(0xFF00F0C8.toInt(), 0xFF00B7FF.toInt(), 0xFF5C7CFF.toInt())
  }

  private fun rebuildShaders() {
    if (width == 0) return
    val p = palette()
    stroke.shader = LinearGradient(0f, 0f, width.toFloat(), 0f, p, null, Shader.TileMode.CLAMP)
    area.shader = LinearGradient(0f, height * 0.25f, 0f, height.toFloat(),
      (p[1] and 0x00FFFFFF) or 0x66000000, p[1] and 0x00FFFFFF, Shader.TileMode.CLAMP)
  }

  override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); rebuildShaders() }

  override fun onDraw(c: Canvas) {
    val now = SystemClock.uptimeMillis()
    val dt = min(now - last, 50L) / 1000f
    last = now
    val speed = when (state) { OverlayState.LISTENING -> 3.2f; OverlayState.THINKING -> 6.5f; OverlayState.SPEAKING -> 4.5f }
    phase += dt * speed
    val target = when (state) {
      OverlayState.LISTENING -> 0.14f + 0.86f * level
      OverlayState.THINKING -> 0.20f + 0.08f * sin(now / 170.0).toFloat()
      OverlayState.SPEAKING -> 0.30f + 0.45f * abs(sin(now / 150.0) * sin(now / 410.0 + 1.0)).toFloat()
    }
    amp += (target - amp) * min(1f, dt * 9f)

    val w = width.toFloat(); val h = height.toFloat()
    val base = h * 0.74f
    for (i in 0 until 3) {
      val freq = 1.3f + i * 0.55f
      val dir = if (i % 2 == 0) 1f else -1f
      val a = amp * h * 0.46f * (1f - i * 0.24f)
      line.rewind(); fill.rewind()
      var x = 0f
      var first = true
      while (x <= w + 6f) {
        val nx = x / w
        val env = sin(PI * nx.coerceIn(0f, 1f)).toFloat().let { it * it }
        val y = base - a * env * sin(nx * freq * 2f * PI.toFloat() + dir * phase * (1f + i * 0.2f) + i * 1.7f)
        if (first) { line.moveTo(x, y); first = false } else line.lineTo(x, y)
        x += 6f
      }
      fill.addPath(line)
      fill.lineTo(w, h); fill.lineTo(0f, h); fill.close()
      area.alpha = 150 - i * 40
      c.drawPath(fill, area)
      stroke.strokeWidth = (3.2f - i * 0.8f) * resources.displayMetrics.density
      stroke.alpha = 255 - i * 60
      c.drawPath(line, stroke)
    }
    postInvalidateOnAnimation()
  }
}

/** Bottom-of-screen assistant card (waves + transcript) shown with a system overlay window. Main thread only. */
class AssistantOverlay(private val ctx: Context, private val onTap: () -> Unit) {
  private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
  private var root: FrameLayout? = null
  private var wave: SiriWaveView? = null
  private var label: TextView? = null
  private val d = ctx.resources.displayMetrics.density
  private fun dp(v: Int) = (v * d).toInt()

  fun show() {
    val bg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xD9020615.toInt()))
    val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.BOTTOM }
    val t = TextView(ctx).apply {
      setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER; maxLines = 4
      setPadding(dp(20), dp(8), dp(20), dp(4)); text = ""
    }
    val w = SiriWaveView(ctx)
    col.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    col.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(130)))
    val r = FrameLayout(ctx).apply { background = bg; isClickable = true; setOnClickListener { onTap() } }
    r.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

    val lp = WindowManager.LayoutParams(
      ViewGroup.LayoutParams.MATCH_PARENT, dp(300),
      WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
      WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
      PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.BOTTOM }

    wm.addView(r, lp) // may throw if the overlay permission was revoked; the caller handles it
    r.translationY = dp(200).toFloat(); r.alpha = 0f
    r.animate().translationY(0f).alpha(1f).setDuration(220).start()
    root = r; wave = w; label = t
  }

  fun setState(s: OverlayState) { wave?.state = s }
  fun setLevel(v: Float) { wave?.level = v.coerceIn(0f, 1f) }
  fun setText(s: String) { label?.text = s }

  fun hide() {
    val r = root ?: return
    root = null; wave = null; label = null
    r.animate().translationY(dp(200).toFloat()).alpha(0f).setDuration(200).withEndAction {
      try { wm.removeView(r) } catch (_: Exception) {}
    }.start()
  }
}
