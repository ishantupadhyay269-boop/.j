package expo.modules.jarvisnative

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Tiny encrypted key/value store (AES-256-GCM, key held in the Android Keystore).
 * Holds the AI key + settings copy used by the background assistant, and the owner voiceprint.
 */
object Vault {
  private const val ALIAS = "jarvis_vault_key"
  private const val PREFS = "jarvis_vault"

  private fun key(): SecretKey {
    val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
    val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    g.init(
      KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .build()
    )
    return g.generateKey()
  }

  fun put(ctx: Context, name: String, value: String) {
    try {
      val c = Cipher.getInstance("AES/GCM/NoPadding")
      c.init(Cipher.ENCRYPT_MODE, key())
      val blob = c.iv + c.doFinal(value.toByteArray(Charsets.UTF_8))
      ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putString(name, Base64.encodeToString(blob, Base64.NO_WRAP)).apply()
    } catch (_: Exception) {}
  }

  fun get(ctx: Context, name: String): String? {
    return try {
      val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(name, null) ?: return null
      val blob = Base64.decode(s, Base64.NO_WRAP)
      val c = Cipher.getInstance("AES/GCM/NoPadding")
      c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, blob.copyOfRange(0, 12)))
      String(c.doFinal(blob.copyOfRange(12, blob.size)), Charsets.UTF_8)
    } catch (_: Exception) { null }
  }

  fun has(ctx: Context, name: String): Boolean =
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(name)

  fun remove(ctx: Context, name: String) {
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(name).apply()
  }
}
