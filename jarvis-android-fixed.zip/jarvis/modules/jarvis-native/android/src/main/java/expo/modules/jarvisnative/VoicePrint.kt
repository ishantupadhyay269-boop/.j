package expo.modules.jarvisnative

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Lightweight on-device "owner voice" matcher: 12 MFCC means + 12 MFCC std-devs + median pitch.
 *
 * HONEST LIMITS: this is classic signal processing, not a neural speaker-ID model. In a synthetic
 * test it only separated speakers weakly (roughly 1 in 4 impostors accepted at a setting that rejected
 * ~6% of the owner's attempts). Treat it as a convenience filter against TV / other people triggering
 * JARVIS, NOT as security. It never gates anything sensitive (lock, calls, SMS keep their own checks).
 */
object VoicePrint {
  const val SR = 16000
  private const val FRAME = 400
  private const val HOP = 160
  private const val NFFT = 512
  private const val NMEL = 26
  private const val NCEP = 13
  private const val DIMS = 25
  private const val F0_WEIGHT = 6.0

  private val window = DoubleArray(FRAME) { 0.54 - 0.46 * cos(2 * PI * it / (FRAME - 1)) }
  private val dct = Array(NCEP) { i -> DoubleArray(NMEL) { j -> cos(PI * i * (j + 0.5) / NMEL) } }
  private val fb: Array<DoubleArray> = buildFilterbank()
  private val twRe = DoubleArray(NFFT / 2) { cos(-2 * PI * it / NFFT) }
  private val twIm = DoubleArray(NFFT / 2) { sin(-2 * PI * it / NFFT) }

  private fun mel(f: Double) = 2595.0 * log10(1.0 + f / 700.0)
  private fun imel(m: Double) = 700.0 * (10.0.pow(m / 2595.0) - 1.0)

  private fun buildFilterbank(): Array<DoubleArray> {
    val lo = mel(80.0); val hi = mel(7600.0)
    val bins = IntArray(NMEL + 2) { i -> Math.floor((NFFT + 1) * imel(lo + (hi - lo) * i / (NMEL + 1)) / SR).toInt() }
    val out = Array(NMEL) { DoubleArray(NFFT / 2 + 1) }
    for (m in 1..NMEL) {
      val l = bins[m - 1]; val c = bins[m]; val r = bins[m + 1]
      for (k in l until c) out[m - 1][k] = (k - l).toDouble() / max(c - l, 1)
      for (k in c until r) out[m - 1][k] = (r - k).toDouble() / max(r - c, 1)
    }
    return out
  }

  /** In-place radix-2 FFT (size NFFT). */
  private fun fft(re: DoubleArray, im: DoubleArray) {
    var j = 0
    for (i in 1 until NFFT) {
      var bit = NFFT shr 1
      while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
      j = j xor bit
      if (i < j) { val tr = re[i]; re[i] = re[j]; re[j] = tr; val ti = im[i]; im[i] = im[j]; im[j] = ti }
    }
    var len = 2
    while (len <= NFFT) {
      val half = len / 2; val step = NFFT / len
      var i = 0
      while (i < NFFT) {
        for (k in 0 until half) {
          val wr = twRe[k * step]; val wi = twIm[k * step]
          val a = i + k; val b = a + half
          val xr = re[b] * wr - im[b] * wi
          val xi = re[b] * wi + im[b] * wr
          re[b] = re[a] - xr; im[b] = im[a] - xi
          re[a] += xr; im[a] += xi
        }
        i += len
      }
      len = len shl 1
    }
  }

  private fun percentile(sorted: DoubleArray, p: Double): Double {
    val k = (sorted.size - 1) * p / 100.0
    val f = Math.floor(k).toInt(); val c = min(f + 1, sorted.size - 1)
    return sorted[f] + (sorted[c] - sorted[f]) * (k - f)
  }

  /** Returns null when the clip has no clear voiced speech (too quiet, too short, or no pitch). */
  fun embed(pcm: ShortArray): DoubleArray? {
    val x = DoubleArray(pcm.size) { pcm[it].toDouble() }
    val n = 1 + (x.size - FRAME) / HOP
    if (n < 25) return null
    val pre = DoubleArray(x.size)
    pre[0] = x[0]
    for (i in 1 until x.size) pre[i] = x[i] - 0.97 * x[i - 1]

    val energy = DoubleArray(n)
    val ceps = Array(n) { DoubleArray(NCEP) }
    val re = DoubleArray(NFFT); val im = DoubleArray(NFFT)
    val logMel = DoubleArray(NMEL)
    for (f in 0 until n) {
      val s = f * HOP
      var e = 0.0
      java.util.Arrays.fill(re, 0.0); java.util.Arrays.fill(im, 0.0)
      for (i in 0 until FRAME) { val v = pre[s + i]; e += v * v; re[i] = v * window[i] }
      energy[f] = ln(e + 1e-6)
      fft(re, im)
      for (m in 0 until NMEL) {
        var acc = 0.0
        val row = fb[m]
        for (k in 0..NFFT / 2) { val w = row[k]; if (w != 0.0) acc += w * (re[k] * re[k] + im[k] * im[k]) }
        logMel[m] = ln(acc + 1e-6)
      }
      for (c in 0 until NCEP) { var a = 0.0; for (m in 0 until NMEL) a += dct[c][m] * logMel[m]; ceps[f][c] = a }
    }

    val sortedE = energy.sortedArray()
    val lo = percentile(sortedE, 10.0); val hi = percentile(sortedE, 90.0)
    if (hi - lo < 2.0) return null
    val thr = lo + 0.4 * (hi - lo)
    val keep = (0 until n).filter { energy[it] > thr }
    if (keep.size < 25) return null

    val out = DoubleArray(DIMS)
    for (c in 1..12) {
      var mean = 0.0
      for (f in keep) mean += ceps[f][c]
      mean /= keep.size
      var v = 0.0
      for (f in keep) { val d = ceps[f][c] - mean; v += d * d }
      out[c - 1] = mean
      out[11 + c] = sqrt(v / keep.size)
    }

    val f0 = ArrayList<Double>()
    for (idx in keep.indices step 2) {
      val s = keep[idx] * HOP
      if (s + 512 > x.size) continue
      pitch(x, s)?.let { f0.add(it) }
    }
    if (f0.size < 10) return null
    f0.sort()
    val med = if (f0.size % 2 == 1) f0[f0.size / 2] else (f0[f0.size / 2 - 1] + f0[f0.size / 2]) / 2
    out[24] = ln(med)
    return out
  }

  private fun pitch(x: DoubleArray, s: Int): Double? {
    var mean = 0.0
    for (i in 0 until 512) mean += x[s + i]
    mean /= 512
    val f = DoubleArray(512) { x[s + it] - mean }
    var e = 0.0
    for (v in f) e += v * v
    if (e < 1.0) return null
    val loLag = SR / 400; val hiLag = SR / 70
    var best = -1.0; var bestLag = 0
    for (lag in loLag until hiLag) {
      var a = 0.0
      for (i in 0 until 512 - lag) a += f[i] * f[i + lag]
      a /= e
      if (a > best) { best = a; bestLag = lag }
    }
    return if (best > 0.35) SR.toDouble() / bestLag else null
  }

  // ---------- enrollment / verification ----------

  class Print(val t: DoubleArray, val sc: DoubleArray, val base: Double)

  private fun dist(a: DoubleArray, b: DoubleArray, sc: DoubleArray): Double {
    var num = 0.0; var den = 0.0
    for (i in 0 until DIMS) {
      val w = if (i == 24) F0_WEIGHT else 1.0
      val d = (a[i] - b[i]) / sc[i]
      num += w * d * d; den += w
    }
    return sqrt(num / den)
  }

  /** Builds and stores the voiceprint from >= 4 enrollment embeddings. Returns the baseline spread, or null. */
  fun enroll(ctx: Context, samples: List<DoubleArray>): Double? {
    if (samples.size < 4) return null
    val n = samples.size
    val t = DoubleArray(DIMS) { d -> samples.sumOf { it[d] } / n }
    val sd = DoubleArray(DIMS) { d -> sqrt(samples.sumOf { (it[d] - t[d]).pow(2) } / n) }
    val sc = DoubleArray(DIMS) { d ->
      val floor = when {
        d < 12 -> 0.3 * samples.sumOf { it[12 + d] } / n
        d < 24 -> 0.15 * abs(t[d])
        else -> 0.08
      }
      max(max(sd[d], floor), 1e-3)
    }
    var base = 0.0
    for (i in 0 until n) {
      val others = DoubleArray(DIMS) { d -> (samples.sumOf { it[d] } - samples[i][d]) / (n - 1) }
      base = max(base, dist(samples[i], others, sc))
    }
    val o = JSONObject()
    o.put("t", JSONArray(t.toList())); o.put("sc", JSONArray(sc.toList())); o.put("base", base)
    Vault.put(ctx, "voiceprint", o.toString())
    return base
  }

  fun enrolled(ctx: Context) = Vault.has(ctx, "voiceprint")
  fun clear(ctx: Context) = Vault.remove(ctx, "voiceprint")

  private fun load(ctx: Context): Print? {
    val raw = Vault.get(ctx, "voiceprint") ?: return null
    return try {
      val o = JSONObject(raw)
      fun arr(k: String) = o.getJSONArray(k).let { a -> DoubleArray(a.length()) { a.getDouble(it) } }
      Print(arr("t"), arr("sc"), o.getDouble("base"))
    } catch (_: Exception) { null }
  }

  enum class State { NO_PRINT, SILENT, NO_VOICE, MATCH, REJECT }
  class Verdict(val state: State, val distance: Double = 0.0, val threshold: Double = 0.0)

  fun threshold(base: Double, strictness: String): Double {
    val f = when (strictness) { "strict" -> 1.15; "relaxed" -> 2.0; else -> 1.5 }
    return max(base * f, 1.2)
  }

  fun verify(ctx: Context, pcm: ShortArray, strictness: String): Verdict {
    val p = load(ctx) ?: return Verdict(State.NO_PRINT)
    var peak = 0
    for (s in pcm) peak = max(peak, abs(s.toInt()))
    if (peak < 60) return Verdict(State.SILENT) // all-zero audio: the mic is blocked / shared
    val e = embed(pcm) ?: return Verdict(State.NO_VOICE)
    val d = dist(e, p.t, p.sc)
    val thr = threshold(p.base, strictness)
    return Verdict(if (d <= thr) State.MATCH else State.REJECT, d, thr)
  }
}
