package expo.modules.jarvisnative

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Foreground service (type: microphone) that loops Android's SpeechRecognizer and watches for the wake phrase.
 *
 * On a wake ("Hello Jarvis", optionally only if it sounds like the enrolled owner) it runs a SIRI-STYLE SESSION:
 * an animated overlay at the bottom of the screen, a spoken "Yes Sir.", then it listens for the command, runs it
 * natively (CommandRouter, then the AI) and speaks the answer. The JARVIS app is NOT opened.
 * Falls back to opening the app when: overlay permission is missing, wakeMode = "app", or the app is already on screen.
 *
 * It is NOT a dedicated low-power hotword DSP: expect battery cost and OEM-specific behaviour.
 */
class WakeWordService : Service() {
  private val handler = Handler(Looper.getMainLooper())
  private val loop = Runnable { listen() }
  private val executor by lazy { Executors.newSingleThreadExecutor() }
  private var recognizer: SpeechRecognizer? = null     // wake-word loop
  private var cmdRecognizer: SpeechRecognizer? = null  // command listening inside a session
  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private var lastWake = 0L
  private var preferOffline = true
  private var errorStreak = 0

  // wake detection
  private var wakePending = false
  private var wakeText = ""
  private val fireRunnable = Runnable { fireWake() }

  // owner-voice audio buffer
  private var ring: AudioRing? = null
  private var ringRetryAt = 0L

  // session
  private var sessionActive = false
  private var sessionId = 0
  private var overlay: AssistantOverlay? = null
  private var retries = 0
  private var onSpeakDone: (() -> Unit)? = null
  private val speakGuard = Runnable { finishSpeak() }
  private val convo = ArrayList<Pair<String, String>>()

  companion object {
    const val CH_SERVICE = "jarvis_service"
    const val CH_WAKE = "jarvis_wake"
    const val ACTION_STOP = "expo.modules.jarvisnative.STOP"
    const val NOTIF_ID = 1001
    val DEFAULT_WORDS = listOf("jarvis", "jarvish", "jarwis", "jarvas", "जार्विस", "जारविस", "जर्विस", "जार्विश")
    private val STOP_RX = Regex("""^(stop|goodbye|bye|that's all|thank you|ruko|bas karo|बस|रुको|धन्यवाद)""", RegexOption.IGNORE_CASE)
  }

  private val prefs get() = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "JARVIS listening", NotificationManager.IMPORTANCE_LOW))
    nm.createNotificationChannel(NotificationChannel(CH_WAKE, "JARVIS wake", NotificationManager.IMPORTANCE_HIGH))
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP) {
      prefs.edit().putBoolean("wake_enabled", false).apply()
      shutdown()
      return START_NOT_STICKY
    }

    try {
      val n = buildServiceNotification()
      if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
      else startForeground(NOTIF_ID, n)
    } catch (e: Exception) {
      // Android 12+ can refuse a microphone foreground service started from the background
      // (e.g. a sticky restart). Give up cleanly; the user re-enables it by opening the app.
      shutdown()
      return START_NOT_STICKY
    }

    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
      prefs.edit().putBoolean("wake_enabled", false).apply()
      shutdown()
      return START_NOT_STICKY
    }

    if (!WakeBus.running) {
      WakeBus.running = true
      tts = TextToSpeech(this) { s ->
        ttsReady = s == TextToSpeech.SUCCESS
        if (ttsReady) {
          tts?.language = Locale("en", "IN")
          tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { handler.post { finishSpeak() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { handler.post { finishSpeak() } }
          })
        }
      }
      WakeBus.onPause = {
        handler.post {
          recognizer?.destroy(); recognizer = null // release the mic for the app's own recognizer
          ring?.stop(); ring = null
          schedule(800)                             // poll until JS calls resumeWake()
        }
      }
      handler.post { listen() }
    }
    return START_STICKY
  }

  private fun buildServiceNotification(): Notification {
    val launch = packageManager.getLaunchIntentForPackage(packageName)
    val open = launch?.let { PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT) }
    val stop = PendingIntent.getService(
      this, 9, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
    return Notification.Builder(this, CH_SERVICE)
      .setContentTitle("JARVIS is listening for \"Hello Jarvis\"")
      .setContentText("Microphone active. Tap to open, or stop listening.")
      .setSmallIcon(R.drawable.ic_jarvis)
      .setOngoing(true)
      .apply { if (open != null) setContentIntent(open) }
      .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_jarvis), "Stop listening", stop).build())
      .build()
  }

  private fun shutdown() {
    WakeBus.running = false
    handler.removeCallbacksAndMessages(null)
    cleanupSession()
    ring?.stop(); ring = null
    stopForeground(STOP_FOREGROUND_REMOVE)
    stopSelf()
  }

  private fun schedule(delayMs: Long) {
    if (!WakeBus.running) return
    handler.removeCallbacks(loop)
    handler.postDelayed(loop, delayMs)
  }

  private fun wakeWords(): List<String> {
    val custom = prefs.getString("wake_words", "")?.split(",")?.map { it.trim().lowercase(Locale.ROOT) }?.filter { it.isNotEmpty() }
    return if (custom.isNullOrEmpty()) DEFAULT_WORDS else custom
  }

  // ------------------------------------------------------------------ wake-word loop

  private fun syncRing() {
    val cfg = Config.load(this)
    val want = cfg.voiceLock && VoicePrint.enrolled(this) && !sessionActive
    if (want && ring == null && SystemClock.elapsedRealtime() >= ringRetryAt) {
      val r = AudioRing()
      if (r.start()) ring = r else { r.stop(); ringRetryAt = SystemClock.elapsedRealtime() + 10_000 }
    } else if (!want && ring != null) { ring?.stop(); ring = null }
  }

  private fun listen() {
    if (!WakeBus.running) return
    if (WakeBus.paused.get() || sessionActive) { schedule(800); return }
    if (!SpeechRecognizer.isRecognitionAvailable(this)) {
      prefs.edit().putBoolean("wake_enabled", false).apply()
      shutdown(); return
    }
    syncRing()
    recognizer?.destroy()
    recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
      r.setRecognitionListener(object : RecognitionListener {
        override fun onResults(b: Bundle?) {
          errorStreak = 0
          val hit = findWake(b)
          if (hit != null) onWakeHeard(hit)
          if (wakePending) { handler.removeCallbacks(fireRunnable); fireWake() } else schedule(250)
        }
        override fun onPartialResults(b: Bundle?) { findWake(b)?.let { onWakeHeard(it) } }
        override fun onError(e: Int) {
          if (wakePending) { handler.removeCallbacks(fireRunnable); fireWake(); return }
          when (e) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
              prefs.edit().putBoolean("wake_enabled", false).apply(); shutdown()
            }
            12, 13 -> { preferOffline = false; schedule(500) } // offline language pack missing: use online
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> schedule(1500)
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> { errorStreak = 0; schedule(250) }
            else -> {
              errorStreak++
              // If the owner-voice buffer and the recognizer fight over the mic, drop the buffer instead of breaking wake.
              if (e == SpeechRecognizer.ERROR_AUDIO && ring != null) {
                ring?.stop(); ring = null; ringRetryAt = SystemClock.elapsedRealtime() + 600_000
                prefs.edit().putString("last_wake_check", "Voice check paused: this phone does not share the microphone.").apply()
              }
              schedule(minOf(300L shl minOf(errorStreak, 4), 5000L)) // network/server errors: back off
            }
          }
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
      })
      val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
      }
      try { r.startListening(i) } catch (_: Exception) { schedule(1500) }
    }
  }

  /** Returns the recognizer hypothesis containing a wake word, or null. */
  private fun findWake(b: Bundle?): String? {
    val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return null
    val words = wakeWords()
    return list.firstOrNull { s -> val l = s.lowercase(Locale.ROOT); words.any { l.contains(it) } }
  }

  /** First partial hit: wait briefly for the final text so "Hello Jarvis, open camera" is one step. */
  private fun onWakeHeard(text: String) {
    if (sessionActive) return
    wakeText = text
    if (!wakePending) { wakePending = true; handler.postDelayed(fireRunnable, 2200) }
  }

  private fun fireWake() {
    if (!wakePending) return
    wakePending = false
    handler.removeCallbacks(fireRunnable)
    recognizer?.cancel()
    val now = SystemClock.elapsedRealtime()
    if (now - lastWake < 3000) { schedule(300); return }
    lastWake = now
    if (!ownerOk()) { schedule(600); return }
    val cfg = Config.load(this)
    val canOverlay = cfg.wakeMode == "overlay" && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) && !WakeBus.appForeground
    if (canOverlay) startSession(extractCommand(wakeText)) else legacyWake()
  }

  private fun extractCommand(text: String): String {
    val l = text.lowercase(Locale.ROOT)
    var best = -1; var len = 0
    for (w in wakeWords()) { val i = l.indexOf(w); if (i >= 0 && (best < 0 || i < best)) { best = i; len = w.length } }
    if (best < 0) return ""
    return text.substring(best + len).trim().trimStart(',', '.', ':', '!', '-', ' ').trim()
  }

  /** Owner-voice filter. Fails OPEN (lets the wake through) when it cannot hear any audio; the reason is shown in Settings. */
  private fun ownerOk(): Boolean {
    val cfg = Config.load(this)
    if (!cfg.voiceLock || !VoicePrint.enrolled(this)) return true
    val r = ring
    if (r == null) { prefs.edit().putString("last_wake_check", "Voice check unavailable (no audio buffer): wake allowed.").apply(); return true }
    val v = VoicePrint.verify(this, r.snapshot(3.0), cfg.strictness)
    val msg = when (v.state) {
      VoicePrint.State.MATCH -> "Last wake: your voice matched (%.2f / %.2f).".format(v.distance, v.threshold)
      VoicePrint.State.REJECT -> "Last wake: ignored, voice did not match (%.2f > %.2f). Loosen sensitivity if this was you.".format(v.distance, v.threshold)
      VoicePrint.State.SILENT -> "Voice check unavailable: this phone gives the app no audio while Google speech is listening. Wake allowed."
      VoicePrint.State.NO_VOICE -> "Last wake: not enough clear speech to check. Wake allowed."
      VoicePrint.State.NO_PRINT -> "No voiceprint."
    }
    prefs.edit().putString("last_wake_check", msg).apply()
    return v.state != VoicePrint.State.REJECT
  }

  // ------------------------------------------------------------------ Siri-style session

  private fun startSession(initial: String) {
    val sid = ++sessionId
    sessionActive = true
    retries = 0
    recognizer?.destroy(); recognizer = null
    ring?.stop(); ring = null
    try {
      overlay = AssistantOverlay(this) { if (sid == sessionId) endSession() }.also { it.show(); it.setState(OverlayState.LISTENING) }
    } catch (_: Exception) { // overlay permission revoked / window refused: use the app instead
      overlay = null; sessionActive = false; sessionId++; legacyWake(); return
    }
    if (initial.isNotBlank()) runCommand(initial, sid)
    else {
      overlay?.setText("Yes, Sir?")
      speak("Yes Sir.") { listenCommand(sid, false) }
    }
  }

  private fun live(sid: Int) = sessionActive && sid == sessionId

  private fun listenCommand(sid: Int, followUp: Boolean) {
    if (!live(sid)) return
    overlay?.setState(OverlayState.LISTENING); overlay?.setText("")
    cmdRecognizer?.destroy(); cmdRecognizer = null
    if (!SpeechRecognizer.isRecognitionAvailable(this)) { endSession(); return }
    val cfg = Config.load(this)
    val r = SpeechRecognizer.createSpeechRecognizer(this)
    cmdRecognizer = r
    r.setRecognitionListener(object : RecognitionListener {
      override fun onRmsChanged(v: Float) { if (live(sid)) overlay?.setLevel((v + 2f) / 12f) }
      override fun onPartialResults(b: Bundle?) {
        if (live(sid)) b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { overlay?.setText(it) }
      }
      override fun onResults(b: Bundle?) {
        if (!live(sid)) return
        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
        if (t.isEmpty()) noSpeech(sid, followUp) else runCommand(t, sid)
      }
      override fun onError(e: Int) {
        if (!live(sid)) return
        when (e) {
          SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> noSpeech(sid, followUp)
          SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> if (retries++ < 2) handler.postDelayed({ listenCommand(sid, followUp) }, 700) else endSession()
          else -> { overlay?.setText("Speech service problem."); say("I could not hear you, Sir.", sid) { endSession() } }
        }
      }
      override fun onReadyForSpeech(p: Bundle?) {}
      override fun onBeginningOfSpeech() {}
      override fun onBufferReceived(b: ByteArray?) {}
      override fun onEndOfSpeech() {}
      override fun onEvent(t: Int, p: Bundle?) {}
    })
    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (cfg.language == "hi") "hi-IN" else "en-IN")
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
    }
    try { r.startListening(i) } catch (_: Exception) { endSession() }
  }

  private fun noSpeech(sid: Int, followUp: Boolean) {
    if (!live(sid)) return
    if (followUp) { endSession(); return }
    if (retries++ < 1) listenCommand(sid, false)
    else say("I didn't catch that, Sir.", sid) { endSession() }
  }

  private fun runCommand(text: String, sid: Int) {
    if (!live(sid)) return
    cmdRecognizer?.destroy(); cmdRecognizer = null
    overlay?.setState(OverlayState.THINKING); overlay?.setText(text)
    val cfg = Config.load(this)
    val locked = getSystemService(KeyguardManager::class.java).isKeyguardLocked
    executor.execute {
      var reply: String? = null
      var needsApp: CommandRouter.Result.NeedsApp? = null
      var stop = false
      try {
        if (STOP_RX.containsMatchIn(text.trim())) stop = true
        else when (val res = CommandRouter.handle(this, text, locked)) {
          is CommandRouter.Result.Reply -> reply = res.text
          is CommandRouter.Result.NeedsApp -> needsApp = res
          null -> {
            synchronized(convo) { convo.add("user" to text); while (convo.size > 12) convo.removeAt(0) }
            val hist = synchronized(convo) { ArrayList(convo) }
            reply = AiClient.ask(cfg, hist)
            synchronized(convo) { convo.add("assistant" to reply!!); while (convo.size > 12) convo.removeAt(0) }
          }
        }
      } catch (e: Exception) { reply = "Something went wrong, Sir." }
      val rep = reply; val na = needsApp; val isStop = stop
      handler.post {
        if (!live(sid)) return@post
        when {
          isStop -> say("Very good, Sir.", sid) { endSession() }
          na != null -> {
            appendLog(text, na.text)
            prefs.edit().putString("pending_command", na.command).apply()
            say(na.text, sid) { bringAppToFront(); endSession() }
          }
          rep.isNullOrBlank() -> endSession()
          else -> {
            appendLog(text, rep!!)
            say(rep, sid) { if (live(sid)) { if (cfg.continuous) { retries = 0; listenCommand(sid, true) } else endSession() } }
          }
        }
      }
    }
  }

  private fun say(text: String, sid: Int, done: () -> Unit) {
    if (!live(sid)) return
    overlay?.setState(OverlayState.SPEAKING); overlay?.setText(text)
    speak(text) { if (live(sid)) done() }
  }

  private fun endSession() {
    if (!sessionActive) return
    cleanupSession()
    schedule(500)
  }

  private fun cleanupSession() {
    sessionActive = false
    sessionId++
    onSpeakDone = null
    handler.removeCallbacks(speakGuard)
    try { tts?.stop() } catch (_: Exception) {}
    cmdRecognizer?.destroy(); cmdRecognizer = null
    overlay?.hide(); overlay = null
  }

  /** Keep a copy of what happened with the app closed so the app can show it in its history. */
  private fun appendLog(user: String, assistant: String) {
    try {
      val arr = JSONArray(prefs.getString("native_log", "[]"))
      arr.put(JSONObject().put("u", user).put("a", assistant))
      val keep = JSONArray()
      for (i in maxOf(0, arr.length() - 30) until arr.length()) keep.put(arr.get(i))
      prefs.edit().putString("native_log", keep.toString()).apply()
    } catch (_: Exception) {}
  }

  // ------------------------------------------------------------------ speech

  private fun speak(text: String, done: () -> Unit) {
    val t = tts
    if (!ttsReady || t == null || text.isBlank()) { handler.post(done); return }
    val cfg = Config.load(this)
    val hindi = text.any { it in '\u0900'..'\u097F' }
    t.language = if (hindi) Locale("hi", "IN") else Locale("en", "IN")
    t.setSpeechRate(cfg.speechRate.coerceIn(0.5f, 2f))
    if (!hindi && cfg.voice != null) try { t.voices?.firstOrNull { it.name == cfg.voice }?.let { t.voice = it } } catch (_: Exception) {}
    onSpeakDone = done
    handler.removeCallbacks(speakGuard)
    handler.postDelayed(speakGuard, 4000L + text.length * 90L) // safety net if TTS never reports completion
    t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
  }

  private fun finishSpeak() {
    handler.removeCallbacks(speakGuard)
    val cb = onSpeakDone ?: return
    onSpeakDone = null
    cb()
  }

  // ------------------------------------------------------------------ legacy: open the full app

  private fun legacyWake() {
    prefs.edit().putLong("pending_wake_ts", System.currentTimeMillis()).apply()
    wakeScreen()
    schedule(8000) // leave room for TTS + app launch; JS pauses the loop while it listens
    speak("Yes Sir.") {
      bringAppToFront()
      WakeBus.listener?.invoke("hello jarvis")
    }
  }

  /** Turn the screen on if it is off, so the user sees JARVIS respond. */
  @Suppress("DEPRECATION")
  private fun wakeScreen() {
    try {
      val pm = getSystemService(PowerManager::class.java)
      if (!pm.isInteractive) {
        pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "jarvis:wake").acquire(10_000L)
      }
    } catch (_: Exception) {}
  }

  private fun bringAppToFront() {
    val launch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    } ?: return
    // Android 10+ blocks background activity starts unless the app holds "draw over other apps".
    if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) {
      try { startActivity(launch) } catch (_: Exception) {}
    }
    // Fallback the user can tap: heads-up / full-screen notification.
    val pi = PendingIntent.getActivity(this, 1, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val n = Notification.Builder(this, CH_WAKE)
      .setContentTitle("JARVIS")
      .setContentText("Yes Sir. Tap to continue.")
      .setSmallIcon(R.drawable.ic_jarvis)
      .setAutoCancel(true)
      .setContentIntent(pi)
      .setFullScreenIntent(pi, true)
      .build()
    getSystemService(NotificationManager::class.java).notify(1002, n)
  }

  override fun onDestroy() {
    WakeBus.running = false
    WakeBus.onPause = null
    handler.removeCallbacksAndMessages(null)
    cleanupSession()
    recognizer?.destroy(); recognizer = null
    ring?.stop(); ring = null
    tts?.shutdown(); tts = null
    try { executor.shutdown() } catch (_: Exception) {}
    super.onDestroy()
  }
}
