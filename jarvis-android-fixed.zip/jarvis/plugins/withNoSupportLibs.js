// Fixes "Duplicate class androidx.versionedparcelable.* found in modules ..."
// Old libs (e.g. @react-native-voice/voice) pull in com.android.support:* (28.0.0)
// which clash with AndroidX. We drop the old support libs from every configuration.
const { withAppBuildGradle } = require('expo/config-plugins');

const MARK = '// jarvis: exclude legacy support libs';
module.exports = function withNoSupportLibs(config) {
  return withAppBuildGradle(config, (cfg) => {
    if (!cfg.modResults.contents.includes(MARK)) {
      cfg.modResults.contents += `
${MARK}
configurations.all {
    exclude group: 'com.android.support'
}
`;
    }
    return cfg;
  });
};
