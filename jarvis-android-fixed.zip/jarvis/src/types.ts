export type Role = 'user' | 'assistant';
export interface Message { id: string; role: Role; text: string; ts: number }
export type Status = 'idle' | 'listening' | 'thinking' | 'speaking';
export type Lang = 'auto' | 'en' | 'hi';
export interface Settings {
  language: Lang;
  speechRate: number;
  voice?: string;
  theme: 'dark' | 'light';
  continuous: boolean;
  wakeEnabled: boolean;
  /** Custom wake word; 'jarvis' = built-in (also matches "hello/hey jarvis"). */
  wakeWord: string;
  /** 'overlay' = Siri-style animation at the bottom, app stays closed. 'app' = open the full JARVIS app. */
  wakeMode: 'overlay' | 'app';
  /** Only react to "Hello Jarvis" when it sounds like the enrolled owner (convenience filter, not security). */
  voiceLock: boolean;
  voiceStrictness: 'strict' | 'normal' | 'relaxed';
  aiProvider: 'openai' | 'gemini';
  aiBaseUrl: string;
  aiModel: string;
  aiApiKey: string;
}
