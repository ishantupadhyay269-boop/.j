import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Pressable, StyleSheet, View } from 'react-native';
import { Status } from '../types';
import { Theme } from './theme';

const BARS = 21;

export function Orb({ status, level, theme, onPress }: { status: Status; level: number; theme: Theme; onPress: () => void }) {
  const pulse = useRef(new Animated.Value(0)).current;
  const spin = useRef(new Animated.Value(0)).current;
  const lv = useRef(level); lv.current = level;
  const bars = useRef([...Array(BARS)].map(() => new Animated.Value(0.15))).current;

  useEffect(() => {
    const speed = status === 'idle' ? 2600 : status === 'thinking' ? 700 : 1100;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: speed, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: speed, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [status]);

  useEffect(() => {
    const l = Animated.loop(Animated.timing(spin, { toValue: 1, duration: status === 'thinking' ? 1800 : 9000, easing: Easing.linear, useNativeDriver: true }));
    l.start();
    return () => l.stop();
  }, [status]);

  useEffect(() => {
    if (status !== 'listening' && status !== 'speaking') { bars.forEach(b => b.setValue(0.12)); return; }
    const timers = bars.map((b, i) => {
      const tick = () => Animated.timing(b, {
        toValue: 0.15 + Math.random() * (status === 'listening' ? 0.4 + lv.current * 0.6 : 0.9),
        duration: 120 + (i % 5) * 30, useNativeDriver: true,
      }).start();
      tick();
      return setInterval(tick, 160 + (i % 4) * 25);
    });
    return () => timers.forEach(clearInterval);
  }, [status]);

  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.08 + level * 0.12] });
  const halo = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.8] });
  const rot = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const rotR = spin.interpolate({ inputRange: [0, 1], outputRange: ['360deg', '0deg'] });
  const c = status === 'speaking' ? '#7be0ff' : status === 'thinking' ? '#9b8cff' : theme.accent;

  return (
    <View style={s.wrap}>
      <Pressable onPress={onPress} style={s.press}>
        <Animated.View style={[s.halo, { backgroundColor: theme.glow, opacity: halo, transform: [{ scale }] }]} />
        <Animated.View style={[s.ring, { borderColor: c, transform: [{ rotate: rot }, { rotateX: '60deg' }] }]} />
        <Animated.View style={[s.ring, s.ring2, { borderColor: c, transform: [{ rotate: rotR }, { rotateY: '60deg' }] }]} />
        <Animated.View style={[s.core, { backgroundColor: c, shadowColor: c, transform: [{ scale }] }]}>
          <View style={s.shine} />
        </Animated.View>
      </Pressable>
      <View style={s.bars}>
        {bars.map((b, i) => (
          <Animated.View key={i} style={[s.bar, { backgroundColor: c, transform: [{ scaleY: b }] }]} />
        ))}
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  wrap: { alignItems: 'center' },
  press: { width: 220, height: 220, alignItems: 'center', justifyContent: 'center' },
  halo: { position: 'absolute', width: 200, height: 200, borderRadius: 100 },
  core: { width: 120, height: 120, borderRadius: 60, shadowOpacity: 1, shadowRadius: 30, elevation: 20, overflow: 'hidden' },
  shine: { position: 'absolute', top: 10, left: 22, width: 46, height: 26, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.35)' },
  ring: { position: 'absolute', width: 190, height: 190, borderRadius: 95, borderWidth: 2 },
  ring2: { width: 170, height: 170, borderRadius: 85, borderWidth: 1.5, opacity: 0.7 },
  bars: { flexDirection: 'row', alignItems: 'center', height: 46, gap: 4 },
  bar: { width: 4, height: 40, borderRadius: 2 },
});
