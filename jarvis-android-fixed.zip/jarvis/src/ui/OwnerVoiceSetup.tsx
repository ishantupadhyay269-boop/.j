import React, { useEffect, useRef, useState } from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { Native } from '../native/JarvisNative';
import { Theme } from './theme';

const NEEDED = 5;
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
const REASON: Record<string, string> = {
  too_quiet: 'I could barely hear you. Speak a little louder and closer to the phone.',
  no_voice: 'I could not find clear speech in that. Say "Hello Jarvis" in a normal voice.',
  mic_unavailable: 'The microphone is busy or not allowed. Close other voice apps and check the microphone permission.',
};
const TEST: Record<string, string> = {
  match: 'Matched: that sounds like the saved owner voice.',
  reject: 'Not a match: that did not sound like the saved owner voice.',
  silent: 'This phone gives the app no audio while the speech service is active, so the voice check cannot run in the background here. "Hello Jarvis" will still work for everyone.',
  no_voice: 'Not enough clear speech to judge. Try again.',
  no_print: 'No voice saved yet.',
  mic_unavailable: REASON.mic_unavailable,
};

type Props = { visible: boolean; onClose: () => void; theme: Theme; onChanged: () => void };

/** Owner voice setup: say "Hello Jarvis" 5 times, then test it. Audio is analysed on the phone and never stored; only a small numeric voiceprint is kept (encrypted). */
export default function OwnerVoiceSetup({ visible, onClose, theme: t, onChanged }: Props) {
  const [count, setCount] = useState(0);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');
  const [enrolled, setEnrolled] = useState(false);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = visible;
    if (!visible) return;
    setCount(0); setMsg(''); setBusy(false); setEnrolled(Native.voiceEnrolled());
    Native.enrollReset();
    Native.pauseWake(); // free the microphone from the background listener while we record
    return () => { alive.current = false; Native.resumeWake(); };
  }, [visible]);

  const record = async () => {
    if (busy) return;
    setBusy(true); setMsg('Get ready…');
    await sleep(900); // let the background listener release the mic
    if (!alive.current) return;
    setMsg('Say "Hello Jarvis" now…');
    const r = await Native.enrollRecordSample();
    if (!alive.current) return;
    if (!r.ok) { setMsg(REASON[r.reason] ?? 'That did not work. Try again.'); setBusy(false); return; }
    setCount(r.count);
    if (r.count >= NEEDED) {
      const f = Native.enrollFinish();
      if (f.ok) { setEnrolled(true); setCount(0); setMsg('Your voice is saved on this phone. You can test it below.'); onChanged(); }
      else setMsg('Could not save the voiceprint. Please start again.');
    } else setMsg(`Good. ${NEEDED - r.count} more.`);
    setBusy(false);
  };

  const test = async () => {
    if (busy) return;
    setBusy(true); setMsg('Get ready…');
    await sleep(900);
    if (!alive.current) return;
    setMsg('Say "Hello Jarvis" now…');
    const r = await Native.testVoice();
    if (!alive.current) return;
    setMsg(`${TEST[r.state] ?? 'Done.'}${r.threshold ? `\nScore ${r.distance.toFixed(2)} (needs ${r.threshold.toFixed(2)} or lower)` : ''}`);
    setBusy(false);
  };

  const remove = () => { Native.clearVoiceprint(); setEnrolled(false); setCount(0); setMsg('Voiceprint deleted.'); onChanged(); };

  const redo = () => { Native.enrollReset(); setCount(0); setMsg(''); };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} statusBarTranslucent>
      <View style={[s.root, { backgroundColor: t.bg }]}>
        <Text style={[s.h, { color: t.accent }]}>Owner voice</Text>
        <Text style={[s.p, { color: t.sub }]}>
          JARVIS learns how you say "Hello Jarvis" so it can ignore other people and the TV. Say it {NEEDED} times in your normal voice, in a quiet place, at the distance you usually speak from.
        </Text>

        {!enrolled || count > 0 ? (
          <>
            <Text style={[s.count, { color: t.text }]}>{count} / {NEEDED}</Text>
            <Pressable disabled={busy} onPress={record} style={[s.btn, { borderColor: t.accent, opacity: busy ? 0.5 : 1 }]}>
              <Text style={{ color: t.accent, textAlign: 'center' }}>{count === 0 ? 'Record sample 1' : `Record sample ${Math.min(count + 1, NEEDED)}`}</Text>
            </Pressable>
          </>
        ) : (
          <>
            <Pressable disabled={busy} onPress={test} style={[s.btn, { borderColor: t.accent, opacity: busy ? 0.5 : 1 }]}>
              <Text style={{ color: t.accent, textAlign: 'center' }}>Test my voice</Text>
            </Pressable>
            <Pressable disabled={busy} onPress={() => { redo(); setEnrolled(false); }} style={[s.btn, { borderColor: t.sub }]}>
              <Text style={{ color: t.text, textAlign: 'center' }}>Record my voice again</Text>
            </Pressable>
            <Pressable disabled={busy} onPress={remove} style={[s.btn, { borderColor: '#ff5a5a' }]}>
              <Text style={{ color: '#ff5a5a', textAlign: 'center' }}>Delete my voiceprint</Text>
            </Pressable>
          </>
        )}

        {!!msg && <Text style={[s.msg, { color: t.text }]}>{msg}</Text>}

        <Text style={[s.note, { color: t.sub }]}>
          This is a lightweight on-device match, not Siri-grade speaker recognition. Similar voices, recordings and noisy rooms can fool it or lock you out, so it is only a convenience filter. It never replaces your fingerprint or PIN for sensitive actions. No audio is saved; the voiceprint is encrypted and stays on this phone.
        </Text>

        <Pressable onPress={onClose} style={[s.btn, { borderColor: t.accent }]}><Text style={{ color: t.accent, textAlign: 'center' }}>Done</Text></Pressable>
      </View>
    </Modal>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, padding: 22, paddingTop: 64 },
  h: { fontSize: 26, fontWeight: '700', letterSpacing: 2, marginBottom: 10 },
  p: { fontSize: 14, lineHeight: 20, marginBottom: 14 },
  count: { fontSize: 40, fontWeight: '700', textAlign: 'center', marginVertical: 10 },
  btn: { borderWidth: 1, borderRadius: 10, padding: 14, marginVertical: 6 },
  msg: { fontSize: 15, lineHeight: 21, textAlign: 'center', marginVertical: 14 },
  note: { fontSize: 12, lineHeight: 17, marginVertical: 10 },
});
