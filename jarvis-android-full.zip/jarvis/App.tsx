import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View, Text, TextInput, TouchableOpacity, FlatList, Modal, Switch, StyleSheet,
  KeyboardAvoidingView, Platform, SafeAreaView, Alert, ScrollView, AppState, PermissionsAndroid,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { Native } from "./modules/jarvis-native";
import * as Network from "expo-network";
import { Orb, Status } from "./src/ui/Orb";
import { SettingsManager, Settings, DEFAULTS } from "./src/modules/SettingsManager";
import { ConversationManager, Msg } from "./src/modules/ConversationManager";
import { AIEngine } from "./src/modules/AIEngine";
import { SpeechEngine } from "./src/modules/SpeechEngine";
import { VoiceEngine } from "./src/modules/VoiceEngine";
import { WakeWordEngine } from "./src/modules/WakeWordEngine";
import { CommandProcessor } from "./src/modules/CommandProcessor";
import { AndroidDeviceController } from "./src/modules/AndroidDeviceController";

const LABEL: Record<Status, string> = {
  idle: "Standing by", wake: "Waiting for “Hello Jarvis”", listening: "Listening…", thinking: "Thinking…", speaking: "Speaking…",
};

export default function App() {
  const [settings, setSettings] = useState<Settings>(DEFAULTS);
  const [status, setStatus] = useState<Status>("idle");
  const [history, setHistory] = useState<Msg[]>([]);
  const [partial, setPartial] = useState("");
  const [text, setText] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const [online, setOnline] = useState(true);
  const [torch, setTorch] = useState(false);
  const [keyInput, setKeyInput] = useState("");
  const s = useRef(settings); s.current = settings;
  const busy = useRef(false);
  const lastWake = useRef(0);
  const [picoInput, setPicoInput] = useState("");

  const dark = settings.theme === "dark";
  const th = dark
    ? { bg: "#020817", card: "#0b1a3a", fg: "#e6f0ff", sub: "#7f94b8", accent: "#2d8bff" }
    : { bg: "#eef4ff", card: "#ffffff", fg: "#0a1a33", sub: "#5a6b88", accent: "#1e6fff" };

  useEffect(() => {
    (async () => {
      const loaded = await SettingsManager.load(); setSettings(loaded);
      if (loaded.backgroundWake && !Native.isWakeRunning()) WakeWordEngine.startBackground();
      setHistory([...(await ConversationManager.load())]);
      AndroidDeviceController.onTorchChange(setTorch);
    })();
    const t = setInterval(async () => { try { setOnline(!!(await Network.getNetworkStateAsync()).isConnected); } catch {} }, 5000);
    return () => { clearInterval(t); VoiceEngine.abort(); SpeechEngine.stop(); };
  }, []);

  const refresh = () => setHistory([...ConversationManager.messages]);

  const say = useCallback(async (msg: string) => {
    setStatus("speaking");
    await SpeechEngine.speak(msg, { lang: s.current.language, rate: s.current.speechRate, voice: s.current.voice });
  }, []);

  const startListening = useCallback(async (afterWake = false) => {
    if (!(await VoiceEngine.ensurePermission())) {
      Alert.alert("Microphone permission needed", "Enable microphone and speech recognition permission for JARVIS in Android settings.");
      setStatus("idle"); return;
    }
    Native.pauseWake(); await new Promise((r) => setTimeout(r, 250));
    setPartial(""); setStatus("listening");
    VoiceEngine.start(s.current.language, {
      onPartial: setPartial,
      onFinal: (t) => { if (t.trim()) handleInput(t.trim()); },
      onError: async (code) => {
        if (code === "no-speech" || code === "speech-timeout") { setStatus("idle"); return; }
        setStatus("idle"); setPartial("");
        await say("I'm sorry, Sir, I didn't catch that. Please try again.");
        setStatus("idle");
      },
      onEnd: () => { if (!busy.current) setStatus((p) => (p === "listening" ? "idle" : p)); },
    });
  }, []);

  const startWake = useCallback(async () => {
    if (!(await VoiceEngine.ensurePermission())) return;
    setStatus("wake");
    VoiceEngine.start(s.current.language, {
      onPartial: onWakeText,
      onFinal: onWakeText,
      onEnd: () => { if (s.current.wakeWordInApp && !busy.current) setTimeout(startWake, 400); },
      onError: () => { if (s.current.wakeWordInApp && !busy.current) setTimeout(startWake, 1500); },
    }, true);
  }, []);

  const onWakeText = async (t: string) => {
    if (busy.current || !WakeWordEngine.matches(t)) return;
    busy.current = true; VoiceEngine.abort();
    const rest = WakeWordEngine.remainder(t);
    await say("Yes Sir.");
    busy.current = false;
    if (rest.length > 2) handleInput(rest); else startListening(true);
  };

  const wakeTriggered = async () => {
    if (Date.now() - lastWake.current < 3000 || busy.current) return;
    lastWake.current = Date.now();
    busy.current = true; VoiceEngine.abort();
    await say("Yes Sir.");
    busy.current = false;
    startListening(true);
  };

  useEffect(() => {
    const a = Native.addListener("onWake", () => wakeTriggered());
    const e = Native.addListener("onWakeError", (ev: any) => {
      Alert.alert("Wake word error", String(ev?.message ?? "unknown error"));
      const next = { ...s.current, backgroundWake: false }; setSettings(next); SettingsManager.save(next);
    });
    const sub = AppState.addEventListener("change", (st2) => { if (st2 === "active" && Native.consumeWakeIntent()) wakeTriggered(); });
    if (Native.consumeWakeIntent()) wakeTriggered();
    return () => { a.remove(); e.remove(); sub.remove(); };
  }, []);

  useEffect(() => { if (status === "idle" && settings.backgroundWake) Native.resumeWake(); }, [status, settings.backgroundWake]);

  const handleInput = useCallback(async (input: string) => {
    if (busy.current) return;
    busy.current = true; VoiceEngine.abort(); setPartial(""); setStatus("thinking");
    await ConversationManager.add("user", input); refresh();
    let reply: string; let after: (() => void) | undefined;
    try {
      const cmd = await CommandProcessor.process(input, say);
      if (cmd.handled) { reply = cmd.reply ?? "Done, Sir."; after = cmd.after; }
      else reply = await AIEngine.ask(ConversationManager.context());
    } catch { reply = "I'm sorry, Sir, something went wrong."; }
    await ConversationManager.add("assistant", reply); refresh();
    await say(reply);
    after?.();
    busy.current = false; setStatus("idle");
    if (s.current.continuous) startListening();
    else if (s.current.wakeWordInApp) startWake();
  }, []);

  const onMic = () => {
    if (status === "speaking") { SpeechEngine.stop(); busy.current = false; startListening(); return; } // interrupt
    if (status === "listening" || status === "wake") { VoiceEngine.abort(); setStatus("idle"); return; }
    startListening();
  };

  const update = async (patch: Partial<Settings>) => {
    const next = { ...settings, ...patch }; setSettings(next); await SettingsManager.save(next);
    if (patch.wakeWordInApp !== undefined) { if (patch.wakeWordInApp) startWake(); else { VoiceEngine.abort(); setStatus("idle"); } }
  };

  const toggleBackground = async (v: boolean) => {
    if (!v) { WakeWordEngine.stopBackground(); const n = { ...settings, backgroundWake: false }; setSettings(n); await SettingsManager.save(n); return; }
    if (!(await VoiceEngine.ensurePermission())) return;
    try { await PermissionsAndroid.request("android.permission.POST_NOTIFICATIONS" as any); } catch {}
    const r = await WakeWordEngine.startBackground();
    if (!r.ok) { Alert.alert("Can't enable background wake word", r.reason); return; }
    VoiceEngine.abort();
    const n = { ...settings, backgroundWake: true, wakeWordInApp: false }; setSettings(n); await SettingsManager.save(n); setStatus("idle");
  };

  return (
    <SafeAreaView style={[st.root, { backgroundColor: th.bg }]}>
      <StatusBar style={dark ? "light" : "dark"} />
      <View style={st.top}>
        <View>
          <Text style={[st.title, { color: th.fg }]}>JARVIS</Text>
          <Text style={{ color: th.sub, fontSize: 11 }}>App by Ishant Upadhyay</Text>
        </View>
        <View style={{ alignItems: "flex-end" }}>
          <Text style={{ color: online ? "#2de27a" : "#ff5a5a", fontSize: 12 }}>● {online ? "Online" : "Offline (basic commands only)"}</Text>
          <TouchableOpacity onPress={() => setShowSettings(true)}><Text style={{ color: th.accent, fontSize: 14, marginTop: 6 }}>⚙ Settings</Text></TouchableOpacity>
        </View>
      </View>

      <Orb status={status} />
      <Text style={[st.status, { color: th.accent }]}>{status === "listening" || status === "wake" ? "🎙 " : ""}{LABEL[status]}</Text>
      {!!partial && <Text style={{ color: th.sub, textAlign: "center", paddingHorizontal: 20 }}>{partial}</Text>}

      <FlatList
        style={{ flex: 1, marginTop: 8 }} contentContainerStyle={{ padding: 14 }}
        data={history} keyExtractor={(m) => String(m.ts)}
        renderItem={({ item }) => (
          <View style={[st.bubble, item.role === "user" ? { alignSelf: "flex-end", backgroundColor: th.accent } : { alignSelf: "flex-start", backgroundColor: th.card }]}>
            <Text style={{ color: item.role === "user" ? "#fff" : th.fg }}>{item.content}</Text>
          </View>
        )}
      />

      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <View style={[st.bar, { backgroundColor: th.card }]}>
          <TextInput
            style={{ flex: 1, color: th.fg, paddingHorizontal: 12 }} placeholder="Type to JARVIS…" placeholderTextColor={th.sub}
            value={text} onChangeText={setText}
            onSubmitEditing={() => { if (text.trim()) { handleInput(text.trim()); setText(""); } }} returnKeyType="send"
          />
          <TouchableOpacity onPress={onMic} style={[st.mic, { backgroundColor: status === "listening" ? "#ff4d6d" : th.accent }]}>
            <Text style={{ fontSize: 22 }}>{status === "listening" ? "⏹" : "🎙"}</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>

      <Modal visible={showSettings} animationType="slide" onRequestClose={() => setShowSettings(false)}>
        <SafeAreaView style={{ flex: 1, backgroundColor: th.bg }}>
          <ScrollView contentContainerStyle={{ padding: 20 }}>
            <Text style={[st.title, { color: th.fg }]}>Settings</Text>
            <Row label="Language" th={th}>
              <Chip th={th} on={settings.language === "en-US"} t="English" p={() => update({ language: "en-US" })} />
              <Chip th={th} on={settings.language === "hi-IN"} t="हिन्दी" p={() => update({ language: "hi-IN" })} />
            </Row>
            <Row label={`Speech speed ${settings.speechRate.toFixed(1)}x`} th={th}>
              <Chip th={th} on={false} t="−" p={() => update({ speechRate: Math.max(0.5, +(settings.speechRate - 0.1).toFixed(1)) })} />
              <Chip th={th} on={false} t="+" p={() => update({ speechRate: Math.min(2, +(settings.speechRate + 0.1).toFixed(1)) })} />
            </Row>
            <Row label="Theme" th={th}>
              <Chip th={th} on={dark} t="Dark" p={() => update({ theme: "dark" })} />
              <Chip th={th} on={!dark} t="Light" p={() => update({ theme: "light" })} />
            </Row>
            <Row label="Continuous conversation" th={th}><Switch value={settings.continuous} onValueChange={(v) => update({ continuous: v })} /></Row>
            <Row label="In-app wake word (app must be open)" th={th}><Switch value={settings.wakeWordInApp} onValueChange={(v) => update({ wakeWordInApp: v })} /></Row>
            <Text style={{ color: th.sub, fontSize: 12, marginBottom: 14 }}>
              The microphone is active only while the 🎙 indicator shows, or while the background wake-word notification is visible.
            </Text>
            <Row label="Background wake word (foreground service)" th={th}><Switch value={settings.backgroundWake} onValueChange={toggleBackground} /></Row>
            <Text style={{ color: th.sub, fontSize: 12, marginBottom: 8 }}>Needs a free Picovoice AccessKey. Shows a persistent notification. Built-in phrase is “Jarvis” unless you add hello_jarvis.ppn. Reliability varies by phone brand.</Text>
            <TextInput style={[st.input, { color: th.fg, borderColor: th.sub }]} secureTextEntry value={picoInput} onChangeText={setPicoInput} placeholder="Picovoice AccessKey" placeholderTextColor={th.sub} autoCapitalize="none" />
            <Chip th={th} on={false} t="Save AccessKey" p={async () => { await SettingsManager.setPicoKey(picoInput.trim()); setPicoInput(""); Alert.alert("Saved", "AccessKey stored securely."); }} />
            <Row label="Phone lock permission (Device Admin)" th={th}>
              <Chip th={th} on={false} t="Enable" p={() => Native.requestAdmin()} />
              <Chip th={th} on={false} t="Remove" p={() => Native.removeAdmin()} />
            </Row>
            <Row label="Run diagnostics (native features)" th={th}><Chip th={th} on={false} t="Check" p={() => Alert.alert("JARVIS diagnostics",
              `Native module: ${Native.available ? "loaded" : "MISSING (use APK/dev build)"}\n` +
              `Device admin (lock): ${Native.isAdminActive() ? "granted" : "not granted"}\n` +
              `Wake service: ${Native.isWakeRunning() ? "running" : "stopped"}\n` +
              `Battery exempt: ${Native.isBatteryExempt() ? "yes" : "no"}\n` +
              `Volume: ${Native.getVolumePercent()}%`)} /></Row>
            <Row label="Ignore battery optimisation" th={th}><Chip th={th} on={false} t="Open" p={() => Native.requestBatteryExemption()} /></Row>
            <Row label="Set JARVIS as default assistant" th={th}><Chip th={th} on={false} t="Open" p={() => Native.openAssistSettings()} /></Row>
            <View style={{ height: 14 }} />
            <Text style={{ color: th.fg, marginBottom: 6 }}>AI API key (stored in Android Keystore)</Text>
            <TextInput style={[st.input, { color: th.fg, borderColor: th.sub }]} secureTextEntry value={keyInput} onChangeText={setKeyInput} placeholder="Paste key" placeholderTextColor={th.sub} autoCapitalize="none" />
            <Chip th={th} on={false} t="Save key" p={async () => { await SettingsManager.setApiKey(keyInput.trim()); setKeyInput(""); Alert.alert("Saved", "API key stored securely."); }} />
            <View style={{ height: 14 }} />
            <Chip th={th} on={false} t="Clear conversation history" p={async () => { await ConversationManager.clear(); refresh(); }} />
            <View style={{ height: 14 }} />
            <Chip th={th} on t="Close" p={() => setShowSettings(false)} />
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const Row = ({ label, th, children }: any) => (
  <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginVertical: 10 }}>
    <Text style={{ color: th.fg, flex: 1 }}>{label}</Text><View style={{ flexDirection: "row" }}>{children}</View>
  </View>
);
const Chip = ({ th, on, t, p }: any) => (
  <TouchableOpacity onPress={p} style={{ paddingVertical: 8, paddingHorizontal: 16, borderRadius: 18, marginLeft: 8, borderWidth: 1, borderColor: th.accent, backgroundColor: on ? th.accent : "transparent" }}>
    <Text style={{ color: on ? "#fff" : th.accent }}>{t}</Text>
  </TouchableOpacity>
);

const st = StyleSheet.create({
  root: { flex: 1 },
  top: { flexDirection: "row", justifyContent: "space-between", padding: 16 },
  title: { fontSize: 26, fontWeight: "700", letterSpacing: 4 },
  status: { textAlign: "center", fontSize: 15, letterSpacing: 1, marginTop: 4 },
  bubble: { maxWidth: "85%", padding: 10, borderRadius: 14, marginVertical: 4 },
  bar: { flexDirection: "row", alignItems: "center", margin: 12, borderRadius: 30, padding: 6 },
  mic: { width: 48, height: 48, borderRadius: 24, alignItems: "center", justifyContent: "center" },
  input: { borderWidth: 1, borderRadius: 10, padding: 10, marginBottom: 10 },
});
