# JARVIS — Android AI voice assistant
App by Ishant Upadhyay.

> **Status: all stages are written, but NOTHING has been compiled or run on a phone.** The Kotlin/Gradle
> native layer in particular is untested and may need fixes on first build. Follow TEST CHECKLIST and report errors.

## What the code contains
| Area | Implementation |
|---|---|
| UI | Orb, waveform (decorative, not real audio levels), mic button, history, text input, settings, dark/light |
| Speech | expo-speech-recognition (EN/HI), expo-speech TTS, tap-to-interrupt, continuous mode, error recovery |
| AI | `AIEngine` provider interface; OpenAI-compatible provider (Groq/OpenRouter/OpenAI); context memory |
| Commands | camera, settings pages, dialer, SMS compose, web/YouTube search, open any installed app, flashlight, volume/mute, alarms, timers, reminders (calendar entry), battery, network, date/time, offline calculator |
| Auth | BiometricPrompt via expo-local-authentication; "authenticate me and …" gates the action |
| Phone lock | `DevicePolicyManager.lockNow()` through a Device Admin (force-lock only) – user must approve in Settings |
| Wake word | In-app text match + background foreground service with Porcupine (`modules/jarvis-native`) |
| Assistant | `VoiceInteractionService` so JARVIS can be chosen as default digital assistant |

## Hard Android limits (by design)
- **No app can unlock the phone.** "Unlock my phone" gets an honest refusal. Auth only gates JARVIS actions.
- Background wake word: foreground service starts only while app is visible; Android 12–14 restrict background mic and activity launches. When the screen is locked, a full-screen/heads-up notification appears and you may need to unlock first. Xiaomi/Oppo/Vivo/Samsung/Huawei may kill the service: disable battery optimisation and allow autostart.
- Porcupine built-in phrase is **"Jarvis"**. For exactly "Hello Jarvis" train a `.ppn` at console.picovoice.ai and save it as `modules/jarvis-native/android/src/main/assets/hello_jarvis.ppn`. Picovoice needs a free AccessKey (check current terms/limits).
- Reminders open a pre-filled calendar entry (Android has no silent reminder API for third-party apps).
- Default-assistant registration requires the user to choose JARVIS in Settings → Default apps → Digital assistant; invocation gesture varies by OEM. The recognition-service stub is the least certain piece.
- Wake word ≠ locked-screen conversation: JARVIS cannot bypass the lock screen.

## Setup
1. Node 20+. `npm install` then `npx expo install --fix`.
2. `cp .env.example .env`, add AI key (or enter it in Settings → stored in Keystore). Keys in `EXPO_PUBLIC_*` are bundled into the app: do not share such an APK publicly.
3. Free services: Groq/OpenRouter free tiers (AI), Android on-device TTS/STT, Picovoice free tier (wake). Verify current limits.
4. Build APK (cloud): `npm i -g eas-cli && eas login && eas init && eas build -p android --profile preview` → download .apk.
   Local alternative: `npx expo prebuild --platform android && cd android && ./gradlew assembleRelease` (needs Android SDK/JDK 17). Release signing: EAS manages the keystore; for local builds create your own keystore.
5. Install: enable "install unknown apps", open the APK on the phone.
   If Gradle says `expo-module-gradle-plugin` not found, your Expo SDK is older: use `apply plugin: 'com.android.library'` + the `ExpoModulesCorePlugin.gradle` template from `npx create-expo-module --local`.

## Stage 4/5 notes
- Wake service is **not** restarted after reboot or swipe-away: Android 14 blocks starting a microphone foreground service from the background. Open JARVIS once after reboot.
- Phone lock uses only the `force-lock` policy. It cannot read/change your PIN or unlock. After a lock, Android requires PIN/biometric as normal.
- Settings → **Run diagnostics** shows whether the native module, device admin, wake service and battery exemption are active. Use it first when testing.
- Wake and assistant triggers are de-duplicated (3 s) so one "Jarvis" produces one "Yes Sir."

## Permissions explained
RECORD_AUDIO (speech + wake word) · FOREGROUND_SERVICE(+_MICROPHONE) (background listening) · POST_NOTIFICATIONS (required notification) · USE_FULL_SCREEN_INTENT (wake pop-up; Android 14 may require manual grant) · USE_BIOMETRIC · REQUEST_IGNORE_BATTERY_OPTIMIZATIONS (reliability; Play Store restricts this) · SET_ALARM · MODIFY_AUDIO_SETTINGS · ACCESS_NETWORK_STATE · BIND_DEVICE_ADMIN / BIND_VOICE_INTERACTION (system-bound components). Torch needs no permission. Installed-app launching uses a `<queries>` entry, not QUERY_ALL_PACKAGES.

## TEST CHECKLIST (do in order on a real phone)
1. App installs and opens; orb animates. 2. Type "what is 12 times 5" (offline calc). 3. Tap mic, ask a question (needs AI key). 4. Hindi: switch language, speak.
5. "open youtube", "flashlight on", "volume up", "set alarm for 7 am", "timer for 2 minutes", "battery". 6. "authenticate me and open camera".
7. Settings → Phone lock Enable → approve → say "lock my phone". 8. Enable Background wake word with AccessKey → say "Jarvis" with app minimised, then with screen off.
9. Settings → default assistant → pick JARVIS → trigger assistant gesture.
Report which step fails plus the `adb logcat` / EAS error text and the code will be fixed.

## Structure
`src/modules`: VoiceEngine, WakeWordEngine, AIEngine, SpeechEngine, AndroidDeviceController, AuthenticationManager, CommandProcessor, ConversationManager, SettingsManager · `src/ui`: Orb · `App.tsx`: MainUI · `modules/jarvis-native`: Kotlin (service, admin, assistant, volume, alarms).
