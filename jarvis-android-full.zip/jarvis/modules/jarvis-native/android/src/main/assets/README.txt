Optional: put a custom Porcupine keyword file here named hello_jarvis.ppn
(train "Hello Jarvis" at console.picovoice.ai, platform Android). Without it,
the built-in keyword "Jarvis" is used.
