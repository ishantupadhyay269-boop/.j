package expo.modules.jarvisnative

/** In-process bridge from native services to the JS module (null when React isn't running). */
object JarvisBridge {
  @Volatile var onWake: ((String) -> Unit)? = null
  @Volatile var onError: ((String) -> Unit)? = null
}
