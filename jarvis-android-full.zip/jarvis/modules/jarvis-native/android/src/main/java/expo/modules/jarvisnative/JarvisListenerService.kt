package expo.modules.jarvisnative

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import ai.picovoice.porcupine.Porcupine
import java.io.File

/** Foreground (microphone) service running the Porcupine wake-word engine.
 *  Must be started while the app is visible (Android 12+/14 restrictions). */
class JarvisListenerService : Service() {
  companion object {
    @Volatile var instance: JarvisListenerService? = null
    const val CH = "jarvis_listen"; const val CH_WAKE = "jarvis_wake"
  }
  private var manager: PorcupineManager? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val key = intent?.getStringExtra("accessKey")
    if (key.isNullOrBlank()) { stopSelf(); return START_NOT_STICKY }
    if (manager != null) return START_NOT_STICKY   // already running
    channels()
    val n = NotificationCompat.Builder(this, CH)
      .setContentTitle("JARVIS is listening for the wake word")
      .setContentText("Microphone active. Open JARVIS settings to turn off.")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
    if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
    instance = this
    try {
      val b = PorcupineManager.Builder().setAccessKey(key).setSensitivity(0.6f)
      val ppn = "hello_jarvis.ppn"
      if (assets.list("")?.contains(ppn) == true) {
        val f = File(filesDir, ppn)
        assets.open(ppn).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        b.setKeywordPath(f.absolutePath)
      } else b.setKeyword(Porcupine.BuiltInKeyword.JARVIS)
      manager = b.build(applicationContext, PorcupineManagerCallback { Handler(Looper.getMainLooper()).post { onDetected() } })
      manager?.start()
    } catch (e: Exception) {
      JarvisBridge.onError?.invoke(e.message ?: "Porcupine failed to start")
      stopSelf()
    }
    return START_NOT_STICKY
  }

  private fun onDetected() {
    try { manager?.stop() } catch (_: Exception) {}   // release the mic for the speech recogniser
    val launch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      putExtra("jarvis_wake", true)
    }
    if (launch != null) {
      // Direct start works only when Android allows it; otherwise the full-screen notification is the fallback.
      try { startActivity(launch) } catch (_: Exception) {}
      val pi = PendingIntent.getActivity(this, 2, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
      val n = NotificationCompat.Builder(this, CH_WAKE).setContentTitle("Yes Sir.").setContentText("Tap to talk to JARVIS")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now).setPriority(NotificationCompat.PRIORITY_HIGH)
        .setCategory(NotificationCompat.CATEGORY_CALL).setFullScreenIntent(pi, true).setContentIntent(pi).setAutoCancel(true)
        .setTimeoutAfter(15000).build()
      (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(2, n)
    }
    JarvisBridge.onWake?.invoke("service")
  }

  fun pause() { try { manager?.stop() } catch (_: Exception) {} }
  fun resume() { try { manager?.start() } catch (_: Exception) {} }

  private fun channels() {
    if (Build.VERSION.SDK_INT >= 26) {
      val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      nm.createNotificationChannel(NotificationChannel(CH, "Wake word listener", NotificationManager.IMPORTANCE_LOW))
      nm.createNotificationChannel(NotificationChannel(CH_WAKE, "Wake word detected", NotificationManager.IMPORTANCE_HIGH))
    }
  }

  override fun onDestroy() {
    try { manager?.stop(); manager?.delete() } catch (_: Exception) {}
    manager = null; instance = null
    super.onDestroy()
  }
}
