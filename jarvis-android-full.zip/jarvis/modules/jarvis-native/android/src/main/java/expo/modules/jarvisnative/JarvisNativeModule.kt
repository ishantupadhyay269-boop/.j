package expo.modules.jarvisnative

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class JarvisNativeModule : Module() {
  private val ctx: Context get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()
  private val admin get() = ComponentName(ctx, JarvisAdminReceiver::class.java)
  private val dpm get() = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
  private val audio get() = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

  private fun launch(i: Intent): Boolean = try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true } catch (_: Exception) { false }

  override fun definition() = ModuleDefinition {
    Name("JarvisNative")
    Events("onWake", "onWakeError")

    OnCreate {
      JarvisBridge.onWake = { src -> sendEvent("onWake", mapOf("source" to src)) }
      JarvisBridge.onError = { msg -> sendEvent("onWakeError", mapOf("message" to msg)) }
    }
    OnDestroy { JarvisBridge.onWake = null; JarvisBridge.onError = null }

    // ---- Flashlight (no CAMERA permission needed for torch) ----
    Function("setTorch") { on: Boolean ->
      try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
          val c = cm.getCameraCharacteristics(it)
          c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true && c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        if (id == null) false else { cm.setTorchMode(id, on); true }
      } catch (_: Exception) { false }
    }

    // ---- Volume (music stream) ----
    Function("getVolumePercent") { audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    Function("setVolumePercent") { p: Int ->
      try { val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC); audio.setStreamVolume(AudioManager.STREAM_MUSIC, (p.coerceIn(0, 100) * max / 100), AudioManager.FLAG_SHOW_UI); true } catch (_: Exception) { false }
    }
    Function("adjustVolume") { dir: Int ->
      try { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (dir > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); true } catch (_: Exception) { false }
    }
    Function("setMuted") { m: Boolean ->
      try { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (m) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); true } catch (_: Exception) { false }
    }

    // ---- Open any launchable app by its label ----
    Function("openAppByName") { name: String ->
      val pm = ctx.packageManager
      val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
      val q = name.lowercase().trim()
      val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == q } ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
      val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
      if (hit != null && li != null && launch(li)) hit.loadLabel(pm).toString() else null
    }

    // ---- Alarms, timers, reminders via official Android intents ----
    Function("setAlarm") { h: Int, m: Int, msg: String ->
      launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, msg).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }
    Function("setTimer") { seconds: Int, msg: String ->
      launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, msg).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }
    Function("addReminder") { title: String, beginMs: Double ->
      val t = beginMs.toLong()
      launch(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, title)
        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, t).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, t + 15 * 60 * 1000))
    }

    // ---- Device admin: phone lock ----
    Function("isAdminActive") { dpm.isAdminActive(admin) }
    Function("requestAdmin") {
      launch(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Allows JARVIS to lock your screen when you ask. It cannot read or change your PIN, or unlock the phone."))
    }
    Function("lockNow") { if (dpm.isAdminActive(admin)) { dpm.lockNow(); true } else false }
    Function("removeAdmin") { try { dpm.removeActiveAdmin(admin); true } catch (_: Exception) { false } }

    // ---- Background wake word service ----
    Function("startWake") { accessKey: String ->
      try { ContextCompat.startForegroundService(ctx, Intent(ctx, JarvisListenerService::class.java).putExtra("accessKey", accessKey)); true } catch (_: Exception) { false }
    }
    Function("stopWake") { ctx.stopService(Intent(ctx, JarvisListenerService::class.java)); true }
    Function("isWakeRunning") { JarvisListenerService.instance != null }
    Function("pauseWake") { JarvisListenerService.instance?.pause(); true }
    Function("resumeWake") { JarvisListenerService.instance?.resume(); true }

    // ---- Wake intent / assistant / battery ----
    Function("consumeWakeIntent") {
      val i = appContext.currentActivity?.intent
      val f = i?.getBooleanExtra("jarvis_wake", false) ?: false
      if (f) i?.removeExtra("jarvis_wake")
      f
    }
    Function("isBatteryExempt") { (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName) }
    Function("requestBatteryExemption") {
      launch(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
    }
    Function("openAssistSettings") {
      launch(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)) || launch(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
    }
  }
}
