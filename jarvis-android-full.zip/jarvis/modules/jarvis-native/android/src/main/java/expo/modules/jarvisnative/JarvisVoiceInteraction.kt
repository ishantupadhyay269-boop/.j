package expo.modules.jarvisnative

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService

/** Lets the user pick JARVIS as the default digital assistant (Settings > Default apps).
 *  When invoked (power-button / corner swipe / hotword per OEM), it opens JARVIS in listening mode. */
class JarvisVoiceInteractionService : VoiceInteractionService()

class JarvisSessionService : VoiceInteractionSessionService() {
  override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

class JarvisSession(ctx: Context) : VoiceInteractionSession(ctx) {
  override fun onShow(args: Bundle?, showFlags: Int) {
    super.onShow(args, showFlags)
    val i = context.packageManager.getLaunchIntentForPackage(context.packageName)
    if (i != null) {
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
      i.putExtra("jarvis_wake", true)
      try { startAssistantActivity(i) } catch (_: Exception) { try { context.startActivity(i) } catch (_: Exception) {} }
    }
    JarvisBridge.onWake?.invoke("assistant")   // app already running: tell JS directly
    hide()
  }
}

/** Minimal stub required for the assistant to be selectable. JARVIS recognises speech via the
 *  system recogniser in the app, not through this service. */
class JarvisRecognitionService : RecognitionService() {
  override fun onStartListening(intent: Intent?, cb: Callback?) { try { cb?.error(android.speech.SpeechRecognizer.ERROR_CLIENT) } catch (_: Exception) {} }
  override fun onStopListening(cb: Callback?) {}
  override fun onCancel(cb: Callback?) {}
}
