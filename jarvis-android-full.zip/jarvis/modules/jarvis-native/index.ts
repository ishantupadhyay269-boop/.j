import { requireNativeModule } from "expo";

let n: any = null;
try { n = requireNativeModule("JarvisNative"); } catch { n = null; } // null in Expo Go / non-dev builds

const f = <T,>(name: string, fallback: T) => (...a: any[]): T => { try { return n ? n[name](...a) : fallback; } catch { return fallback; } };

export const Native = {
  available: !!n,
  setTorch: f<boolean>("setTorch", false),
  getVolumePercent: f<number>("getVolumePercent", -1),
  setVolumePercent: f<boolean>("setVolumePercent", false),
  adjustVolume: f<boolean>("adjustVolume", false),
  setMuted: f<boolean>("setMuted", false),
  openAppByName: f<string | null>("openAppByName", null),
  setAlarm: f<boolean>("setAlarm", false),
  setTimer: f<boolean>("setTimer", false),
  addReminder: f<boolean>("addReminder", false),
  isAdminActive: f<boolean>("isAdminActive", false),
  requestAdmin: f<boolean>("requestAdmin", false),
  lockNow: f<boolean>("lockNow", false),
  removeAdmin: f<boolean>("removeAdmin", false),
  startWake: f<boolean>("startWake", false),
  stopWake: f<boolean>("stopWake", false),
  isWakeRunning: f<boolean>("isWakeRunning", false),
  pauseWake: f<boolean>("pauseWake", false),
  resumeWake: f<boolean>("resumeWake", false),
  consumeWakeIntent: f<boolean>("consumeWakeIntent", false),
  isBatteryExempt: f<boolean>("isBatteryExempt", false),
  requestBatteryExemption: f<boolean>("requestBatteryExemption", false),
  openAssistSettings: f<boolean>("openAssistSettings", false),
  addListener(event: "onWake" | "onWakeError", cb: (e: any) => void): { remove: () => void } {
    return n ? n.addListener(event, cb) : { remove() {} };
  },
};
