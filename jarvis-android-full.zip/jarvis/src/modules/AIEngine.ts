import { SettingsManager } from "./SettingsManager";

export type ChatMsg = { role: "system" | "user" | "assistant"; content: string };

/** Provider interface: swap implementations without touching the rest of the app. */
export interface AIProvider { chat(messages: ChatMsg[]): Promise<string>; }

/** Works with any OpenAI-compatible API (Groq, OpenRouter, OpenAI, local servers...). */
export class OpenAICompatProvider implements AIProvider {
  constructor(private baseUrl: string, private model: string) {}
  async chat(messages: ChatMsg[]): Promise<string> {
    const key = await SettingsManager.getApiKey();
    if (!key) throw new Error("NO_KEY");
    const res = await fetch(`${this.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model: this.model, messages, temperature: 0.6, max_tokens: 400 }),
    });
    if (!res.ok) throw new Error(`HTTP_${res.status}`);
    const data = await res.json();
    return data?.choices?.[0]?.message?.content?.trim() ?? "";
  }
}

const SYSTEM = `You are JARVIS, a polite, professional, confident voice assistant. Address the user as "Sir".
Reply in the language the user used (English, Hindi, or mixed Hinglish). Keep answers short and speakable:
no markdown, no lists unless asked. You can calculate, translate, summarize and explain. Use prior context for follow-ups.`;

let provider: AIProvider = new OpenAICompatProvider(
  process.env.EXPO_PUBLIC_AI_BASE_URL || "https://api.groq.com/openai/v1",
  process.env.EXPO_PUBLIC_AI_MODEL || "llama-3.3-70b-versatile"
);

export const AIEngine = {
  setProvider(p: AIProvider) { provider = p; },
  async ask(history: { role: "user" | "assistant"; content: string }[]): Promise<string> {
    try {
      const out = await provider.chat([{ role: "system", content: SYSTEM }, ...history]);
      return out || "I'm sorry, Sir, I received an empty response.";
    } catch (e: any) {
      if (e?.message === "NO_KEY") return "Sir, no AI API key is configured. Please add one in Settings.";
      return "I'm sorry, Sir. I couldn't reach the AI service. Please check your connection.";
    }
  },
};
