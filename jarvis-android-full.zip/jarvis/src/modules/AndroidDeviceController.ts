import { Linking } from "react-native";
import * as IntentLauncher from "expo-intent-launcher";
import * as Battery from "expo-battery";
import * as Network from "expo-network";
import { Native } from "../../modules/jarvis-native";

export type Result = { ok: boolean; message: string };
let torchListener: (on: boolean) => void = () => {};
let torchOn = false;
const NEED_NATIVE = "That needs the JARVIS native module, Sir. Please use the installed APK build rather than Expo Go.";

async function tryOpen(url: string): Promise<boolean> { try { await Linking.openURL(url); return true; } catch { return false; } }
async function intent(action: string): Promise<boolean> { try { await IntentLauncher.startActivityAsync(action); return true; } catch { return false; } }

export const AndroidDeviceController = {
  onTorchChange(fn: (on: boolean) => void) { torchListener = fn; },

  async openApp(name: string): Promise<Result> {
    if (!Native.available) return { ok: false, message: NEED_NATIVE };
    const label = Native.openAppByName(name);
    return label ? { ok: true, message: `Opening ${label}.` } : { ok: false, message: `I couldn't find an installed app called ${name}, Sir.` };
  },
  async openCamera(): Promise<Result> { return (await intent("android.media.action.STILL_IMAGE_CAMERA")) ? { ok: true, message: "Opening the camera." } : { ok: false, message: "I couldn't open the camera." }; },
  async openSettings(page?: "wifi" | "bluetooth" | "sound" | "battery" | "display"): Promise<Result> {
    const map: Record<string, string> = { wifi: "android.settings.WIFI_SETTINGS", bluetooth: "android.settings.BLUETOOTH_SETTINGS", sound: "android.settings.SOUND_SETTINGS", battery: "android.settings.BATTERY_SAVER_SETTINGS", display: "android.settings.DISPLAY_SETTINGS" };
    return (await intent(page ? map[page] : "android.settings.SETTINGS")) ? { ok: true, message: "Opening settings." } : { ok: false, message: "I couldn't open settings." };
  },
  async dial(n: string): Promise<Result> { return (await tryOpen(`tel:${n}`)) ? { ok: true, message: "Opening the dialer. Please press call to confirm." } : { ok: false, message: "I couldn't open the dialer." }; },
  async composeSms(n: string, body = ""): Promise<Result> { return (await tryOpen(`sms:${n}?body=${encodeURIComponent(body)}`)) ? { ok: true, message: "Message composed. Please press send." } : { ok: false, message: "I couldn't open messaging." }; },
  async search(q: string): Promise<Result> { return (await tryOpen(`https://www.google.com/search?q=${encodeURIComponent(q)}`)) ? { ok: true, message: `Searching for ${q}.` } : { ok: false, message: "I couldn't open the browser." }; },
  async youtubeSearch(q: string): Promise<Result> { return (await tryOpen(`https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`)) ? { ok: true, message: `Searching YouTube for ${q}.` } : { ok: false, message: "I couldn't open YouTube." }; },
  async battery(): Promise<Result> {
    const lvl = Math.round((await Battery.getBatteryLevelAsync()) * 100);
    const charging = (await Battery.getBatteryStateAsync()) === Battery.BatteryState.CHARGING;
    return { ok: true, message: `Battery is at ${lvl} percent${charging ? " and charging" : ""}, Sir.` };
  },
  async network(): Promise<Result> { const s = await Network.getNetworkStateAsync(); return { ok: true, message: s.isConnected ? "You are online, Sir." : "You are currently offline, Sir." }; },
  dateTime(): Result {
    const d = new Date();
    return { ok: true, message: `It is ${d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} on ${d.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" })}.` };
  },
  flashlight(on?: boolean): Result {
    if (!Native.available) return { ok: false, message: NEED_NATIVE };
    const want = on ?? !torchOn;
    if (!Native.setTorch(want)) return { ok: false, message: "I couldn't control the flashlight on this device, Sir." };
    torchOn = want; torchListener(want);
    return { ok: true, message: want ? "Flashlight on." : "Flashlight off." };
  },
  volume(action: "up" | "down" | "mute" | "unmute" | { set: number }): Result {
    if (!Native.available) return { ok: false, message: NEED_NATIVE };
    const ok = typeof action === "object" ? Native.setVolumePercent(action.set)
      : action === "up" ? Native.adjustVolume(1) : action === "down" ? Native.adjustVolume(-1) : Native.setMuted(action === "mute");
    return ok ? { ok: true, message: "Done, Sir." } : { ok: false, message: "I couldn't change the volume, Sir." };
  },
  alarm(h: number, m: number, label = "JARVIS alarm"): Result {
    return Native.setAlarm(h, m, label) ? { ok: true, message: `Alarm set for ${h % 12 || 12}:${String(m).padStart(2, "0")} ${h >= 12 ? "PM" : "AM"}.` } : { ok: false, message: "I couldn't set the alarm, Sir." };
  },
  timer(seconds: number): Result {
    return Native.setTimer(seconds, "JARVIS timer") ? { ok: true, message: `Timer started for ${Math.round(seconds / 60 * 10) / 10} minutes.` } : { ok: false, message: "I couldn't start the timer, Sir." };
  },
  reminder(title: string, when: Date): Result {
    return Native.addReminder(title, when.getTime()) ? { ok: true, message: "I've opened a calendar entry for that reminder. Please tap save to confirm, Sir." } : { ok: false, message: "I couldn't open the calendar, Sir." };
  },
  lock(): { ok: boolean; message: string; needsAdmin?: boolean } {
    if (!Native.available) return { ok: false, message: NEED_NATIVE };
    if (!Native.isAdminActive()) { Native.requestAdmin(); return { ok: false, needsAdmin: true, message: "Sir, I need your permission first. Please approve device administrator access on screen, then ask me again." }; }
    return { ok: true, message: "Locking your phone, Sir." };
  },
};
