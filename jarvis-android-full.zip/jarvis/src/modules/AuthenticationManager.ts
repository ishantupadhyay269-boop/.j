import * as LocalAuth from "expo-local-authentication";

/** Uses Android BiometricPrompt (via expo-local-authentication). Never sees PIN/password.
 *  Gates JARVIS actions only; it cannot unlock the Android lock screen (no app can). */
export const AuthenticationManager = {
  async available(): Promise<boolean> {
    return (await LocalAuth.hasHardwareAsync()) && (await LocalAuth.isEnrolledAsync());
  },
  async authenticate(): Promise<boolean> {
    if (!(await this.available())) return false;
    const r = await LocalAuth.authenticateAsync({
      promptMessage: "JARVIS: authenticate to continue",
      disableDeviceFallback: false,
    });
    return r.success;
  },
};
