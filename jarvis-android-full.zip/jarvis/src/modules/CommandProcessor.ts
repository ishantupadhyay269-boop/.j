import { AndroidDeviceController as D } from "./AndroidDeviceController";
import { AuthenticationManager } from "./AuthenticationManager";
import { Native } from "../../modules/jarvis-native";

export type Outcome = { handled: boolean; reply?: string; after?: () => void };
const T = (s: string) => s.toLowerCase().replace(/^jarvis[, ]*/i, "").trim();

/** Tiny safe arithmetic evaluator (works offline). */
function calc(t: string): string | null {
  let e = t.replace(/what is|what's|calculate|equals|=|\?/g, " ")
    .replace(/\bplus\b/g, "+").replace(/\bminus\b/g, "-").replace(/\b(times|multiplied by|into|x)\b/g, "*")
    .replace(/\b(divided by|over)\b/g, "/").replace(/\bpercent of\b/g, "/100*").replace(/\s+/g, "");
  if (!/^[\d+\-*/().%]+$/.test(e) || !/\d[+\-*/]\d/.test(e)) return null;
  let i = 0;
  const peek = () => e[i];
  const num = (): number => { if (peek() === "(") { i++; const v = expr(); i++; return v; } if (peek() === "-") { i++; return -num(); } const m = e.slice(i).match(/^\d+(\.\d+)?/); if (!m) throw 0; i += m[0].length; return parseFloat(m[0]); };
  const term = (): number => { let v = num(); while (peek() === "*" || peek() === "/") { const o = e[i++]; const r = num(); v = o === "*" ? v * r : v / r; } return v; };
  const expr = (): number => { let v = term(); while (peek() === "+" || peek() === "-") { const o = e[i++]; const r = term(); v = o === "+" ? v + r : v - r; } return v; };
  try { const v = expr(); return i === e.length && isFinite(v) ? `${Math.round(v * 1e6) / 1e6}` : null; } catch { return null; }
}

/** Parse "7", "7:30", "7 pm", "19:45" -> next Date at that time. */
function parseClock(s: string): Date | null {
  const m = s.match(/(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?/i);
  if (!m) return null;
  let h = parseInt(m[1], 10); const min = m[2] ? parseInt(m[2], 10) : 0; const ap = m[3]?.toLowerCase().replace(/\./g, "");
  if (ap === "pm" && h < 12) h += 12; if (ap === "am" && h === 12) h = 0;
  if (h > 23 || min > 59) return null;
  const d = new Date(); d.setHours(h, min, 0, 0); if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
  return d;
}
const UNIT = (u: string) => (/^h/.test(u) ? 3600 : /^m/.test(u) ? 60 : 1);

async function run(t: string): Promise<Outcome> {
  let m: RegExpMatchArray | null;
  if (/\b(battery)\b|बैटरी/.test(t)) return { handled: true, reply: (await D.battery()).message };
  if (/\b(network status|am i online|internet status)\b/.test(t)) return { handled: true, reply: (await D.network()).message };

  if ((m = t.match(/(?:timer|टाइमर)(?: for)? (\d+(?:\.\d+)?) ?(second|sec|minute|min|hour|hr)s?/)))
    return { handled: true, reply: D.timer(parseFloat(m[1]) * UNIT(m[2])).message };
  if ((m = t.match(/remind me (?:to )?(.+?) in (\d+) ?(minute|min|hour|hr)s?/))) {
    const when = new Date(Date.now() + parseInt(m[2], 10) * UNIT(m[3]) * 1000);
    return { handled: true, reply: D.reminder(m[1], when).message };
  }
  if ((m = t.match(/remind me (?:to )?(.+?) at (.+)/))) {
    const when = parseClock(m[2]);
    if (when) return { handled: true, reply: D.reminder(m[1], when).message };
  }
  if ((m = t.match(/(?:set (?:an? )?alarm|wake me)(?: up)?(?: for| at)? (.+)/))) {
    const when = parseClock(m[1]);
    if (when) return { handled: true, reply: D.alarm(when.getHours(), when.getMinutes()).message };
    return { handled: true, reply: "I didn't catch the time, Sir. Try 'set alarm for 7:30 AM'." };
  }

  if ((m = t.match(/(?:set )?volume (?:to )?(\d{1,3})/))) return { handled: true, reply: D.volume({ set: parseInt(m[1], 10) }).message };
  if (/volume up|increase (the )?volume|louder|आवाज़ बढ़ा/.test(t)) return { handled: true, reply: D.volume("up").message };
  if (/volume down|decrease (the )?volume|lower (the )?volume|quieter|आवाज़ कम/.test(t)) return { handled: true, reply: D.volume("down").message };
  if (/\bunmute\b/.test(t)) return { handled: true, reply: D.volume("unmute").message };
  if (/\bmute\b|म्यूट/.test(t)) return { handled: true, reply: D.volume("mute").message };

  if (/\b(flashlight|torch)\b|टॉर्च/.test(t)) {
    const on = /\boff\b|बंद/.test(t) ? false : /\bon\b|चालू/.test(t) ? true : undefined;
    return { handled: true, reply: D.flashlight(on).message };
  }
  if (/lock (my |the )?(phone|screen)|फोन लॉक/.test(t)) {
    const r = D.lock();
    return r.ok ? { handled: true, reply: r.message, after: () => Native.lockNow() } : { handled: true, reply: r.message };
  }
  if (/\bcamera\b|कैमरा/.test(t)) return { handled: true, reply: (await D.openCamera()).message };
  if ((m = t.match(/open (wifi|bluetooth|sound|battery|display) settings/))) return { handled: true, reply: (await D.openSettings(m[1] as any)).message };
  if (/open settings|सेटिंग/.test(t)) return { handled: true, reply: (await D.openSettings()).message };
  if ((m = t.match(/(?:play|search youtube for|youtube search) (.+)/))) return { handled: true, reply: (await D.youtubeSearch(m[1])).message };
  if ((m = t.match(/(?:call|dial) ([\d +\-]{3,})/))) return { handled: true, reply: (await D.dial(m[1].replace(/\s/g, ""))).message };
  if ((m = t.match(/(?:send (?:an )?sms|text|message) (?:to )?([\d +\-]{3,})(?: (?:saying|that) (.+))?/))) return { handled: true, reply: (await D.composeSms(m[1].replace(/\s/g, ""), m[2] || "")).message };
  if ((m = t.match(/(?:search|google)(?: for| the web for)? (.+)/))) return { handled: true, reply: (await D.search(m[1])).message };
  if ((m = t.match(/open (.+)/))) return { handled: true, reply: (await D.openApp(m[1])).message };

  const c = calc(t); if (c !== null) return { handled: true, reply: `The answer is ${c}, Sir.` };
  if (/\b(what('s| is) the time|what time|current time|today's date|what('s| is) the date|what day)\b|समय क्या|तारीख क्या/.test(t)) return { handled: true, reply: D.dateTime().message };
  return { handled: false };
}

export const CommandProcessor = {
  async process(raw: string, speak: (s: string) => Promise<void>): Promise<Outcome> {
    const t = T(raw);
    if (/(unlock|open) my phone/.test(t))
      return { handled: true, reply: "I'm sorry, Sir. Android does not allow any app to unlock the phone. I can authenticate you for JARVIS actions, though." };
    const m = t.match(/authenticate me and (.+)/);
    if (m) {
      await speak("Certainly, Sir. Please authenticate to continue.");
      if (!(await AuthenticationManager.authenticate())) return { handled: true, reply: "Authentication failed or is unavailable, Sir. Command cancelled." };
      const out = await run(T(m[1]));
      return out.handled ? out : { handled: true, reply: "Authenticated, Sir, but I didn't understand that command." };
    }
    return run(t);
  },
};
