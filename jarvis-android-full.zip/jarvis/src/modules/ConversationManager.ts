import AsyncStorage from "@react-native-async-storage/async-storage";

export type Msg = { role: "user" | "assistant"; content: string; ts: number };
const KEY = "jarvis.history";
const MAX = 60;

export const ConversationManager = {
  messages: [] as Msg[],
  async load() {
    try { const r = await AsyncStorage.getItem(KEY); this.messages = r ? JSON.parse(r) : []; } catch { this.messages = []; }
    return this.messages;
  },
  async add(role: Msg["role"], content: string) {
    this.messages.push({ role, content, ts: Date.now() });
    if (this.messages.length > MAX) this.messages = this.messages.slice(-MAX);
    try { await AsyncStorage.setItem(KEY, JSON.stringify(this.messages)); } catch {}
  },
  context(n = 12) { return this.messages.slice(-n).map(({ role, content }) => ({ role, content })); },
  async clear() { this.messages = []; await AsyncStorage.removeItem(KEY); },
};
