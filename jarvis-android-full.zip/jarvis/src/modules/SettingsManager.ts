import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";

export type Settings = {
  language: "en-US" | "hi-IN";
  speechRate: number;
  voice?: string;
  theme: "dark" | "light";
  wakeWordInApp: boolean;
  continuous: boolean;
  backgroundWake: boolean;
};
export const DEFAULTS: Settings = {
  language: "en-US", speechRate: 1.0, theme: "dark", wakeWordInApp: false, continuous: false, backgroundWake: false,
};
const KEY = "jarvis.settings";

export const SettingsManager = {
  async load(): Promise<Settings> {
    try { const r = await AsyncStorage.getItem(KEY); return r ? { ...DEFAULTS, ...JSON.parse(r) } : DEFAULTS; }
    catch { return DEFAULTS; }
  },
  async save(s: Settings) { try { await AsyncStorage.setItem(KEY, JSON.stringify(s)); } catch {} },
  /** Optional: user-entered API key kept in Android Keystore-backed storage. */
  async getApiKey(): Promise<string> {
    try { return (await SecureStore.getItemAsync("jarvis.apikey")) || process.env.EXPO_PUBLIC_AI_API_KEY || ""; }
    catch { return process.env.EXPO_PUBLIC_AI_API_KEY || ""; }
  },
  async setApiKey(k: string) { await SecureStore.setItemAsync("jarvis.apikey", k); },
  async getPicoKey(): Promise<string> { try { return (await SecureStore.getItemAsync("jarvis.picokey")) || ""; } catch { return ""; } },
  async setPicoKey(k: string) { await SecureStore.setItemAsync("jarvis.picokey", k); },
};
