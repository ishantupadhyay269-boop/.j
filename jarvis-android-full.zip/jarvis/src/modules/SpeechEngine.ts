import * as Speech from "expo-speech";

export const SpeechEngine = {
  speak(text: string, opts: { lang: string; rate: number; voice?: string }): Promise<void> {
    return new Promise((resolve) => {
      Speech.stop();
      Speech.speak(text, {
        language: opts.lang, rate: opts.rate, voice: opts.voice,
        onDone: () => resolve(), onStopped: () => resolve(), onError: () => resolve(),
      });
    });
  },
  stop() { Speech.stop(); },
  async voices() { try { return await Speech.getAvailableVoicesAsync(); } catch { return []; } },
};
