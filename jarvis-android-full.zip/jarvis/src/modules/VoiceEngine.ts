import { ExpoSpeechRecognitionModule } from "expo-speech-recognition";

type Handlers = {
  onPartial?: (t: string) => void;
  onFinal: (t: string) => void;
  onEnd?: () => void;
  onError?: (code: string) => void;
};
let subs: { remove: () => void }[] = [];
const clear = () => { subs.forEach((s) => s.remove()); subs = []; };

export const VoiceEngine = {
  async ensurePermission(): Promise<boolean> {
    const r = await ExpoSpeechRecognitionModule.requestPermissionsAsync();
    return r.granted;
  },
  start(lang: string, h: Handlers, continuous = false) {
    clear();
    subs.push(
      ExpoSpeechRecognitionModule.addListener("result", (e: any) => {
        const t = e.results?.[0]?.transcript ?? "";
        if (e.isFinal) h.onFinal(t); else h.onPartial?.(t);
      }),
      ExpoSpeechRecognitionModule.addListener("error", (e: any) => h.onError?.(e.error)),
      ExpoSpeechRecognitionModule.addListener("end", () => h.onEnd?.())
    );
    ExpoSpeechRecognitionModule.start({ lang, interimResults: true, continuous });
  },
  stop() { try { ExpoSpeechRecognitionModule.stop(); } catch {} },
  abort() { try { ExpoSpeechRecognitionModule.abort(); } catch {} clear(); },
};
