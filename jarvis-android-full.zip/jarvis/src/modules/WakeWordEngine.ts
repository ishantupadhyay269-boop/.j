import { Native } from "../../modules/jarvis-native";
import { SettingsManager } from "./SettingsManager";

/** Two layers:
 *  1) In-app text matching of "hello jarvis" while the app is open (speech-recognition stream).
 *  2) Background/screen-off detection via a native foreground service running Porcupine
 *     (needs a free Picovoice AccessKey; built-in keyword is "Jarvis" unless you add hello_jarvis.ppn).
 *  Background reliability varies by phone brand/Android version and must be tested on your device. */
const RE = /(hello|hallo|hullo)\s+jarvis|हेलो\s*जार्विस|हैलो\s*जार्विस/i;

export const WakeWordEngine = {
  matches(t: string): boolean { return RE.test(t); },
  remainder(t: string): string { return t.replace(RE, "").trim(); },
  async startBackground(): Promise<{ ok: boolean; reason?: string }> {
    if (!Native.available) return { ok: false, reason: "Native module missing. Use a development/APK build, not Expo Go." };
    const key = await SettingsManager.getPicoKey();
    if (!key) return { ok: false, reason: "Add your Picovoice AccessKey in Settings first." };
    return Native.startWake(key) ? { ok: true } : { ok: false, reason: "Could not start the service." };
  },
  stopBackground() { Native.stopWake(); },
};
