import React, { useEffect, useRef } from "react";
import { Animated, Easing, View } from "react-native";

export type Status = "idle" | "wake" | "listening" | "thinking" | "speaking";
const COLORS: Record<Status, string> = {
  idle: "#1e6fff", wake: "#18b6ff", listening: "#2de2ff", thinking: "#8a6bff", speaking: "#3d8bff",
};

export function Orb({ status, size = 190 }: { status: Status; size?: number }) {
  const pulse = useRef(new Animated.Value(0)).current;
  const spin = useRef(new Animated.Value(0)).current;
  const bars = useRef([...Array(9)].map(() => new Animated.Value(0.2))).current;

  useEffect(() => {
    const speed = status === "idle" ? 2600 : status === "thinking" ? 700 : 1100;
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: speed, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: speed, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [status]);

  useEffect(() => {
    const l = Animated.loop(Animated.timing(spin, { toValue: 1, duration: 9000, easing: Easing.linear, useNativeDriver: true }));
    l.start(); return () => l.stop();
  }, []);

  // Decorative waveform: animates while listening/speaking. It is NOT driven by real audio levels.
  useEffect(() => {
    const active = status === "listening" || status === "speaking";
    const anims = bars.map((b, i) => Animated.loop(Animated.sequence([
      Animated.timing(b, { toValue: active ? 1 : 0.2, duration: 300 + i * 60, useNativeDriver: true }),
      Animated.timing(b, { toValue: 0.2, duration: 300 + i * 60, useNativeDriver: true }),
    ])));
    anims.forEach((a) => a.start());
    return () => anims.forEach((a) => a.stop());
  }, [status]);

  const c = COLORS[status];
  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.12] });
  const glow = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.8] });
  const rot = spin.interpolate({ inputRange: [0, 1], outputRange: ["0deg", "360deg"] });

  return (
    <View style={{ alignItems: "center", justifyContent: "center", height: size * 1.5 }}>
      <Animated.View style={{ position: "absolute", width: size * 1.3, height: size * 1.3, borderRadius: size, backgroundColor: c, opacity: glow, transform: [{ scale }] }} />
      <Animated.View style={{ position: "absolute", width: size * 1.15, height: size * 1.15, borderRadius: size, borderWidth: 2, borderColor: c, borderStyle: "dashed", transform: [{ rotate: rot }] }} />
      <Animated.View style={{ width: size, height: size, borderRadius: size, backgroundColor: "#04122e", borderWidth: 3, borderColor: c, alignItems: "center", justifyContent: "center", transform: [{ scale }] }}>
        <View style={{ flexDirection: "row", alignItems: "center", height: 60 }}>
          {bars.map((b, i) => (
            <Animated.View key={i} style={{ width: 6, height: 56, marginHorizontal: 3, borderRadius: 3, backgroundColor: c, transform: [{ scaleY: b }] }} />
          ))}
        </View>
      </Animated.View>
    </View>
  );
}
